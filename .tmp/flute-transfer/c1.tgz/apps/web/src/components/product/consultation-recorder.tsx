"use client";

import { useTranslations } from "next-intl";
import { type ReactNode, useCallback, useEffect, useRef, useState } from "react";

import {
  Alert,
  Box,
  Button,
  Card,
  CardContent,
  Dialog,
  DialogActions,
  DialogContent,
  LinearProgress,
  Skeleton,
  Typography,
} from "@mui/material";

import ConsultationStepHeader from "@/components/product/consultation-step-header";
import DialogHeader from "@/components/product/dialog-header";
import InfoHint from "@/components/product/info-hint";
import { type PersistedWebRecording, useRecordingSession } from "@/components/product/recording-session-provider";
import { useAudioAllowance } from "@/hooks/use-audio-allowance";
import NiCheckSquare from "@/icons/nexture/ni-check-square";
import NiClock from "@/icons/nexture/ni-clock";
import NiMicrophone from "@/icons/nexture/ni-microphone";
import NiPause from "@/icons/nexture/ni-pause";
import NiSquare from "@/icons/nexture/ni-square";
import { graceDaysLeft, trialDaysLeft } from "@/lib/audio-allowance";
import { recordAudit } from "@/lib/audit";
import {
  clearTabAlert,
  markTabAlert,
  notificationPermission,
  notifyCaptureFailure,
  requestNotificationPermission,
} from "@/lib/capture-alert";
import { getProductAction } from "@/lib/product-actions";
import { trackCommercialEvent } from "@/lib/product-events";
import { ChunkBatcher } from "@/lib/recording-buffer";
import { cn } from "@/lib/utils";
import { clearWebRecordingRequest, getOrCreateWebRecordingRequest } from "@/lib/web-recording-request";
import { isSupabaseConfigured } from "@flyee/auth";
import { createClient } from "@flyee/auth/client";

type Phase = "idle" | "recording" | "paused" | "uploading" | "processing" | "ready" | "error";
type ConsentState = { audio: boolean; ai: boolean };
type RecordingMode = "ai" | "audio_only";
/** A server-side capture left open with no local audio to recover from. */
type OrphanRecording = { id: string; status: string; createdAt: string };

const responseCode = (body: unknown): string | undefined => {
  if (!body || typeof body !== "object") return undefined;
  const error = (body as { error?: unknown }).error;
  if (typeof error === "string") return error;
  return error && typeof error === "object" ? String((error as { code?: unknown }).code ?? "") : undefined;
};

/**
 * A post-upload failure that carries WHY it failed. A bare `Error` collapsed
 * every cause into the same "temporary unavailability", so a provider that
 * definitively refused and a consent that is no longer valid both invited a
 * retry that could never succeed.
 */
class ProcessingError extends Error {
  constructor(readonly code: string) {
    super(code);
    this.name = "ProcessingError";
  }
}

const processingErrorCode = (cause: unknown) => (cause instanceof ProcessingError ? cause.code : "processing_failed");

/** Blocked by consent: resolved by registering it, never by trying again. */
const isConsentFailure = (code: string) =>
  code === "consent_required" || code === "audio_consent_required" || code === "ai_consent_required";
/**
 * Only offer a retry when a retry can actually work — an ALLOW-list, because a
 * deny-list silently lets every unlisted code promise a new attempt. The codes
 * left out are the structural ones the rest of the product already treats as
 * unrecoverable (`invalid_consultation_transition`, `recording_not_uploaded`,
 * `recording_invalid_state` — see UNRECOVERABLE_CLAIM_CODES in
 * lib/clinical-jobs.ts, which the recovery sweep stamps on `error_code`), plus
 * the allowance and authorization refusals. Pressing "tentar novamente" against
 * any of those fails every single time.
 */
const RETRYABLE_PROCESSING_FAILURES = new Set([
  "provider_unavailable",
  "clinical_revision_conflict",
  "internal_error",
  "processing_failed",
]);
const isRetryableFailure = (code: string) => RETRYABLE_PROCESSING_FAILURES.has(code);

const bestMime = () => {
  const candidates = ["audio/webm;codecs=opus", "audio/webm", "audio/mp4"];
  return candidates.find((mime) => MediaRecorder.isTypeSupported(mime)) ?? "";
};

const sha256 = async (blob: Blob) => {
  if (!crypto.subtle) return null;
  const digest = await crypto.subtle.digest("SHA-256", await blob.arrayBuffer());
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
};

const MAX_DURATION_SECONDS = 120 * 60;
const MAX_SIZE_BYTES = 512 * 1024 * 1024;
const BILLING_HREF = `${getProductAction("billing").href}?source=consultation&feature=audio`;
// A recused card is not resolved by choosing a plan — it lands on the
// subscription itself, where the payment method is.
const PAYMENT_HREF = `${getProductAction("billing").href}?source=consultation&feature=payment`;
const PACK_HREF = `${getProductAction("billing").href}?source=consultation&feature=audio_pack`;

// Statuses from which `begin_clinical_recording` may resume the SAME capture.
// A row OUTSIDE this set (cancelled / failed / ready) means the stored upload
// id is spent — reusing it hands back a dead row and every state call 409s.
const RESUMABLE_RECORDING_STATUSES = new Set(["recording", "local", "uploading", "uploaded", "processing"]);

/** Recoverable, consented browser capture backed by the recording state RPCs. */
export default function ConsultationRecorder({
  orgId,
  patientId,
  consultationId,
  audioConsent,
  aiConsent,
  onRequestConsent,
  onChanged,
  secondaryCapture,
  paymentPending = false,
}: {
  orgId: string;
  patientId: string;
  consultationId: string;
  audioConsent?: boolean;
  aiConsent?: boolean;
  onRequestConsent?: () => void;
  onChanged?: () => void;
  /** An alternate capture method (e.g. phone-via-QR), rendered inside this
   * same card so the two never compete as separate "step 1" cards. */
  secondaryCapture?: ReactNode;
  /**
   * A paid plan is charged and waiting on the provider (a PIX not yet
   * confirmed). The trial offer's note says "when it ends, your account goes
   * back to Gratuito" — false for someone who has just paid, and shown to her
   * right after checkout by the guided onboarding. Optional and false by
   * default, so every other caller reads exactly what it read before.
   */
  paymentPending?: boolean;
}) {
  const t = useTranslations("product");
  const trialNote = paymentPending ? t("recorder-trial-note-pending") : t("recorder-trial-note");
  const {
    setActive: setSessionActive,
    persist: persistSession,
    appendChunk,
    recover: recoverSession,
    remove: removeSession,
    uploadTus,
  } = useRecordingSession();
  const [consents, setConsents] = useState<ConsentState | null>(null);
  const [phase, setPhase] = useState<Phase>("idle");
  const [seconds, setSeconds] = useState(0);
  const [nearSizeLimit, setNearSizeLimit] = useState(false);
  const [captureLimit, setCaptureLimit] = useState<"duration" | "size" | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  // Every capture exists to be transcribed and feed the AI — there is no
  // "record just to store audio" outcome (the manual anamnesis is the non-AI
  // path). So the mode is fixed, not a choice the professional has to make.
  const mode: RecordingMode = "ai";
  const {
    allowance,
    trialParams,
    loading: allowanceLoading,
    error: allowanceError,
    reload: reloadAllowance,
  } = useAudioAllowance(orgId);
  const [trialDialog, setTrialDialog] = useState(false);
  const [startingTrial, setStartingTrial] = useState(false);
  const [micPrimer, setMicPrimer] = useState<{ startTrial: boolean } | null>(null);
  const [micBlocked, setMicBlocked] = useState(false);
  const [orphan, setOrphan] = useState<OrphanRecording | null>(null);
  const [discardingOrphan, setDiscardingOrphan] = useState(false);
  const [level, setLevel] = useState(0);
  /** Silence watchdog: the mic is open but nothing is reaching it. */
  const [silent, setSilent] = useState(false);
  // The audio uploaded fine but the AI prep step failed. This is NOT a lost
  // recording, so it must never render as a capture failure that invites
  // re-recording. The CAUSE is kept, not just the fact: a busy provider, a
  // definitive refusal and a missing consent lead to three different next
  // steps, and only one of them is "tentar novamente".
  const [processingFailure, setProcessingFailure] = useState<string | null>(null);
  /**
   * The microphone was lost mid-take. Survives the upload (which clears
   * `error`) so the end of the flow can say the audio is PARTIAL instead of
   * announcing a complete success over half a consultation.
   */
  const [captureInterrupted, setCaptureInterrupted] = useState(false);
  /** The status poll gave up before the job settled — informative, not a failure. */
  const [pollTimedOut, setPollTimedOut] = useState(false);
  const [confirmFinish, setConfirmFinish] = useState(false);
  const upgradePromptViewed = useRef(false);

  const mediaRecorder = useRef<MediaRecorder | null>(null);
  const chunks = useRef<Blob[]>([]);
  const stream = useRef<MediaStream | null>(null);
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);
  const secondsRef = useRef(0);
  const bytesRef = useRef(0);
  const recordingId = useRef<string | null>(null);
  const recordingMode = useRef<RecordingMode>("ai");
  const clientUploadId = useRef<string | null>(null);
  const pendingBlob = useRef<{ blob: Blob; duration: number; mime: string } | null>(null);
  // Elapsed time is derived from the wall clock, never from accumulated ticks:
  // a background tab throttles setInterval and would under-report the duration.
  const startedAtRef = useRef(0);
  const pausedTotalRef = useRef(0);
  const pausedAtRef = useRef(0);
  const audioContextRef = useRef<AudioContext | null>(null);
  const levelFrameRef = useRef<number | null>(null);
  const loudAtRef = useRef(0);
  // A dead capture row is salvaged into a fresh one at most once per capture,
  // so a persistent server rejection can never become an upload loop.
  const salvageAttemptedRef = useRef(false);
  /** Groups timeslices into the batches written to IndexedDB during capture. */
  const batcher = useRef(new ChunkBatcher());
  /**
   * Serializes those writes. `ondataavailable` is not async, so without a chain
   * two batches could be encrypted concurrently and land out of order — and the
   * assembly refuses a sequence with a hole, which would turn a recoverable
   * capture into a lost one.
   */
  const chunkChain = useRef<Promise<void>>(Promise.resolve());

  /**
   * Hand the open batch to storage, if there is one. Fire-and-forget on
   * purpose: a failed local write must never interrupt the capture in progress
   * — the in-memory copy is still the primary, this is the safety net.
   */
  const flushChunks = useCallback(
    (mimeType: string) => {
      const id = recordingId.current;
      // The microphone is opened BEFORE the server row exists (no device, no
      // row), so the first timeslices can arrive with no id yet. Keep them in
      // the batcher instead of draining it: taking a batch we cannot store
      // would advance `seq` past a gap, and the assembly rightly refuses a
      // sequence with a hole — the header lives in seq 0.
      if (!id) return;
      const batch = batcher.current.take();
      if (!batch) return;
      const meta = {
        recordingId: id,
        consultationId,
        orgId,
        mime: mimeType,
        mode: recordingMode.current,
        elapsedSeconds: secondsRef.current,
        createdAt: chunkStartedAtRef.current,
        updatedAt: new Date().toISOString(),
      };
      chunkChain.current = chunkChain.current
        .then(() => appendChunk(meta, batch.seq, batch.parts))
        .catch(() => undefined);
    },
    [appendChunk, consultationId, orgId],
  );
  /** Stamped once per capture so recovery can tell takes apart. */
  const chunkStartedAtRef = useRef(new Date(0).toISOString());

  /**
   * The audio is uploaded and safe; only the AI prep failed. Keeps the server's
   * cause, which is what decides the copy and whether a retry is offered at all.
   */
  const failProcessing = useCallback((code: string) => {
    setError(null);
    setProcessingFailure(code);
    setPhase("error");
  }, []);

  const pollUntilSettled = useCallback(
    async (id: string) => {
      setPollTimedOut(false);
      setPhase("processing");
      for (let attempt = 0; attempt < 100; attempt += 1) {
        const { data } = await createClient().from("recordings").select("status,error_code").eq("id", id).maybeSingle();
        if (data?.status === "ready") {
          setPhase("ready");
          onChanged?.();
          return;
        }
        if (data?.status === "cancelled") {
          // Discarded while this page waited on it. Polling on would spin for
          // five minutes on a recording that will never be processed.
          failProcessing("recording_cancelled");
          onChanged?.();
          return;
        }
        if (data?.status === "failed") {
          // A job that failed in the background reports its cause on the row —
          // the request itself succeeded, so this is the only place it exists.
          failProcessing(typeof data.error_code === "string" ? data.error_code : "processing_failed");
          onChanged?.();
          return;
        }
        await new Promise((resolve) => window.setTimeout(resolve, 3_000));
      }
      // Not an error: the job legitimately outlives this poll when the provider
      // is congested and Inngest spreads its retries over minutes. Red is
      // reserved for risk and failure, and the recordings panel below keeps
      // tracking the real state.
      setPollTimedOut(true);
      setPhase("processing");
    },
    [failProcessing, onChanged],
  );

  const requestProcessing = useCallback(
    async (id: string) => {
      setPhase("processing");
      const response = await fetch(`/api/recordings/${id}/process`, { method: "POST" });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) {
        const code = responseCode(body);
        if (!code || !["processing_already_claimed"].includes(code)) {
          throw new ProcessingError(code ?? "processing_failed");
        }
      }
      await pollUntilSettled(id);
    },
    [pollUntilSettled],
  );

  /**
   * Resume polling when she comes back to the tab.
   *
   * The poll gives up after ~5 minutes, and until now it never restarted: from
   * then on the card showed "Preparando…" forever, whatever the job had
   * actually done. Returning to the tab is exactly the moment she wants the
   * current answer.
   */
  useEffect(() => {
    if (!pollTimedOut || phase !== "processing") return;
    const onVisible = () => {
      const id = recordingId.current;
      if (!id || document.visibilityState !== "visible") return;
      void pollUntilSettled(id);
    };
    document.addEventListener("visibilitychange", onVisible);
    return () => document.removeEventListener("visibilitychange", onVisible);
  }, [pollTimedOut, phase, pollUntilSettled]);

  /**
   * The functions recovery needs, kept in a ref so recovery does NOT re-run
   * when their identity changes.
   *
   * Recovery answers one question — "what did a previous page leave behind for
   * this consultation?" — and it is only true when the recorder appears. It
   * used to list these callbacks as effect dependencies, and they are rebuilt
   * whenever the caller passes a new `onChanged` (an inline arrow re-renders
   * into a new function). Measured in the guided onboarding: starting a capture
   * calls `onChanged`, the page re-rendered, recovery ran AGAIN mid-capture,
   * found no local audio yet and flagged the recording in progress as an
   * abandoned one — offering "Descartar e liberar", which cancels the capture
   * she is making.
   */
  const recoveryFns = useRef({ recoverSession, removeSession, requestProcessing, failProcessing, t });
  useEffect(() => {
    recoveryFns.current = { recoverSession, removeSession, requestProcessing, failProcessing, t };
  });

  useEffect(() => {
    let current = true;
    const { recoverSession, removeSession, requestProcessing, failProcessing, t } = recoveryFns.current;
    void recoverSession(consultationId).then(async (recovered) => {
      if (!current) return;

      // No audio preserved locally. A row still OPEN on the server is then a
      // capture that died mid-flight (a reload, a closed tab, a refused
      // microphone). Nothing can be recovered from it, and while it stands the
      // server refuses every new capture — so it must be surfaced with a way
      // out instead of leaving the consultation permanently unable to record.
      if (!recovered) {
        const { data: open } = await createClient()
          .from("recordings")
          .select("id, status, created_at")
          .eq("consultation_id", consultationId)
          .in("status", ["recording", "local", "uploading"])
          .order("created_at", { ascending: false })
          .limit(1)
          .maybeSingle();
        // Never the capture THIS recorder is running: that one is not orphaned,
        // and "discard" on it would cancel the consultation being recorded.
        if (!current || !open || open.id === recordingId.current) return;
        setOrphan({ id: open.id as string, status: open.status as string, createdAt: open.created_at as string });
        return;
      }

      const { data } = await createClient()
        .from("recordings")
        .select("status, mode")
        .eq("id", recovered.recordingId)
        .maybeSingle();
      if (!current) return;
      // The ref still tracks the RECOVERED recording's real mode (a legacy
      // audio_only capture in flight must finish as audio_only); only the new
      // capture default is fixed to AI.
      const recoveredMode = data?.mode === "audio_only" || recovered.mode === "audio_only" ? "audio_only" : "ai";
      recordingMode.current = recoveredMode;
      recordingId.current = recovered.recordingId;
      if (data?.status === "ready") {
        await removeSession(recovered.recordingId);
        setPhase("ready");
        return;
      }
      if (data?.status === "uploaded" || data?.status === "processing") {
        await removeSession(recovered.recordingId);
        if (recoveredMode === "audio_only") {
          setPhase("ready");
          return;
        }
        void requestProcessing(recovered.recordingId).catch((cause) => {
          failProcessing(processingErrorCode(cause));
        });
        return;
      }
      pendingBlob.current = { blob: recovered.blob, duration: recovered.duration, mime: recovered.mime };
      // Assembled from the batches written during the capture: the take never
      // reached its end, so say how much was saved instead of implying the
      // whole consultation is here.
      if (recovered.partial) setCaptureInterrupted(true);
      setError(
        recovered.partial
          ? t("recorder-recovered-partial", { minutes: Math.max(1, Math.round(recovered.duration / 60)) })
          : t("recorder-recovered"),
      );
      setPhase("error");
    });
    return () => {
      current = false;
    };
    // Once per consultation, deliberately — see `recoveryFns` above.
  }, [consultationId]);

  useEffect(() => {
    if (audioConsent !== undefined && aiConsent !== undefined) {
      setConsents({ audio: audioConsent, ai: aiConsent });
      return;
    }
    const check = async () => {
      if (!isSupabaseConfigured) {
        setConsents({ audio: false, ai: false });
        return;
      }
      const supabase = createClient();
      const [{ data: audio }, { data: ai }] = await Promise.all([
        supabase.rpc("has_active_consent", {
          target_org: orgId,
          target_patient: patientId,
          term_slug: "audio-recording",
        }),
        supabase.rpc("has_active_consent", {
          target_org: orgId,
          target_patient: patientId,
          term_slug: "ai-processing",
        }),
      ]);
      setConsents({ audio: Boolean(audio), ai: Boolean(ai) });
    };
    void check();
  }, [aiConsent, audioConsent, orgId, patientId]);

  /**
   * Asks for notification permission only AFTER a capture succeeded — the
   * moment the value is proven and the ask makes sense. On page load it would
   * be reflexively dismissed, and a denied permission never prompts again.
   * Notifications are the channel that reaches her when her attention is on
   * the patient; they stay silent (there is a patient in the room).
   */
  useEffect(() => {
    if (phase !== "ready" || notificationPermission() !== "default") return;
    void requestNotificationPermission();
  }, [phase]);

  const stopTimer = () => {
    if (timer.current) clearInterval(timer.current);
    timer.current = null;
  };
  const stopLevelMeter = useCallback(() => {
    if (levelFrameRef.current !== null) cancelAnimationFrame(levelFrameRef.current);
    levelFrameRef.current = null;
    void audioContextRef.current?.close().catch(() => undefined);
    audioContextRef.current = null;
    setLevel(0);
    setSilent(false);
  }, []);
  const releaseStream = useCallback(() => {
    stream.current?.getTracks().forEach((track) => track.stop());
    stream.current = null;
  }, []);

  /**
   * Live input level. This is the only honest proof that sound is reaching the
   * microphone — a running timer proves a timer runs, not that the consultation
   * is being captured. Doubles as a silence watchdog.
   */
  const startLevelMeter = useCallback((media: MediaStream) => {
    const AudioContextCtor =
      window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextCtor) return;
    try {
      const context = new AudioContextCtor();
      audioContextRef.current = context;
      const analyser = context.createAnalyser();
      analyser.fftSize = 1024;
      context.createMediaStreamSource(media).connect(analyser);
      const buffer = new Uint8Array(analyser.frequencyBinCount);
      loudAtRef.current = Date.now();
      const tick = () => {
        analyser.getByteTimeDomainData(buffer);
        let peak = 0;
        for (const sample of buffer) peak = Math.max(peak, Math.abs(sample - 128));
        const normalized = Math.min(1, peak / 96);
        setLevel(normalized);
        if (normalized > 0.06) loudAtRef.current = Date.now();
        // A whole minute without any signal is a broken microphone, not a pause
        // in the conversation.
        setSilent(Date.now() - loudAtRef.current > 60_000);
        levelFrameRef.current = requestAnimationFrame(tick);
      };
      levelFrameRef.current = requestAnimationFrame(tick);
    } catch {
      // A missing/blocked AudioContext must never prevent the capture itself.
      audioContextRef.current = null;
    }
  }, []);

  useEffect(
    () => () => {
      stopTimer();
      stopLevelMeter();
      releaseStream();
      setSessionActive(false);
      clearTabAlert(document);
    },
    [releaseStream, setSessionActive, stopLevelMeter],
  );

  const setRecordingState = useCallback(async (id: string, body: Record<string, unknown>) => {
    const response = await fetch(`/api/recordings/${id}/state`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(responseCode(result) ?? "recording_invalid_state");
    return result;
  }, []);

  /** Discards any stored upload id and returns a brand-new one. */
  const mintFreshUploadId = useCallback(() => {
    clearWebRecordingRequest(window.sessionStorage, consultationId);
    clientUploadId.current = null;
    return getOrCreateWebRecordingRequest(window.sessionStorage, consultationId, () => crypto.randomUUID());
  }, [consultationId]);

  /**
   * Opens (or idempotently resumes) a server recording row. A reused upload id
   * whose row is no longer startable (a prior capture that was cancelled or
   * failed) is reported as `stale_upload_id` rather than handed back as if it
   * were resumable — driving such a row forward always 409s.
   */
  const beginServerRecording = useCallback(
    async (
      uploadId: string,
      startTrial: boolean,
    ): Promise<{ ok: true; recordingId: string } | { ok: false; code: string; recordingId?: string }> => {
      const response = await fetch(`/api/consultations/${consultationId}/recordings`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          mode,
          clientUploadId: uploadId,
          startTrial: mode === "ai" && startTrial,
          capturedOn: "web",
        }),
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) {
        return {
          ok: false,
          code: responseCode(body) ?? "recorder_error",
          recordingId: typeof body?.recordingId === "string" ? body.recordingId : undefined,
        };
      }
      // Server may resolve the id to an EXISTING row. Only reuse it when it is
      // genuinely resumable; a terminal row means the id is spent (belt to the
      // 0049 server guard, and self-healing before that migration is applied).
      if (body.code === "existing" && !RESUMABLE_RECORDING_STATUSES.has(body.status)) {
        return { ok: false, code: "stale_upload_id" };
      }
      if (typeof body.recordingId !== "string" || !body.recordingId) {
        return { ok: false, code: "invalid_begin_response" };
      }
      return { ok: true, recordingId: body.recordingId };
    },
    [consultationId, mode],
  );

  /** Frees a dead capture so this consultation can be recorded again. */
  const discardOrphan = async () => {
    if (!orphan || discardingOrphan) return;
    setDiscardingOrphan(true);
    try {
      await setRecordingState(orphan.id, { action: "cancel", errorCode: "abandoned_capture" });
      setOrphan(null);
      setError(null);
      setPhase("idle");
      clearWebRecordingRequest(window.sessionStorage, consultationId);
      clientUploadId.current = null;
      onChanged?.();
    } catch {
      setError(t("recorder-orphan-discard-error"));
    } finally {
      setDiscardingOrphan(false);
    }
  };

  /**
   * The capture stopped without her asking — the microphone was unplugged, a
   * Bluetooth headset dropped, or the OS revoked the device. Her attention is
   * on the patient, so this must reach her OUTSIDE this tab.
   */
  const handleCaptureLoss = useCallback(() => {
    if (mediaRecorder.current && mediaRecorder.current.state !== "inactive") {
      // Flush whatever was captured; onstop uploads it so nothing is lost.
      mediaRecorder.current.stop();
    }
    stopTimer();
    stopLevelMeter();
    setSessionActive(false);
    setError(t("recorder-device-lost"));
    // `error` is cleared by the upload that this stop() triggers, so the fact
    // that the take was CUT SHORT has to survive somewhere the happy path does
    // not touch. Without it the flow ended on a green "pronta para revisão"
    // over an audio that may cover half the appointment, and the gap surfaced
    // only during clinical review — or never.
    setCaptureInterrupted(true);
    markTabAlert(document, t("recorder-alert-tab"));
    notifyCaptureFailure(t("recorder-alert-title"), t("recorder-alert-body"));
  }, [setSessionActive, stopLevelMeter, t]);

  const upload = useCallback(
    async (blob: Blob, duration: number, mime: string) => {
      const id = recordingId.current;
      if (!id) return;
      pendingBlob.current = { blob, duration, mime };
      setPhase("uploading");
      setUploadProgress(0);
      setError(null);
      setProcessingFailure(null);
      let uploadConfirmed = false;
      try {
        const checksum = await sha256(blob);
        if (!checksum) throw new Error("checksum_unavailable");
        // A non-empty but sub-second capture measures 0s (also true of blobs
        // persisted before this floor existed). mark_recording_local rejects a
        // 0 duration as invalid (surfaced as 413), so floor any real audio to
        // one second — the billed duration is measured server-side regardless.
        const durationSeconds = blob.size > 0 ? Math.max(1, duration) : duration;
        const persistedRecording: PersistedWebRecording = {
          recordingId: id,
          consultationId,
          orgId,
          duration: durationSeconds,
          mime,
          checksumSha256: checksum,
          createdAt: new Date().toISOString(),
          mode: recordingMode.current,
          blob,
        };
        await persistSession(persistedRecording);
        clearWebRecordingRequest(window.sessionStorage, consultationId);
        clientUploadId.current = null;
        await setRecordingState(id, {
          action: "local",
          durationSeconds,
          sizeBytes: blob.size,
          mime,
          checksumSha256: checksum,
        });
        await setRecordingState(id, { action: "uploading" });

        const extension = mime.includes("mp4") ? "m4a" : "webm";
        const path = `${orgId}/${id}.${extension}`;
        const supabase = createClient();
        await uploadTus(persistedRecording, path, setUploadProgress);

        await setRecordingState(id, { action: "uploaded", audioPath: path });
        uploadConfirmed = true;
        await recordAudit(supabase, "recording.uploaded", {
          orgId,
          entityType: "recording",
          entityId: id,
          metadata: { consultationId, durationSeconds: duration },
        });
        pendingBlob.current = null;
        await removeSession(id);
        onChanged?.();
        if (recordingMode.current === "ai") {
          try {
            await requestProcessing(id);
          } catch (cause) {
            // The audio is uploaded and safe — only the AI prep failed. Name
            // the CAUSE instead of an error that reads as a lost recording and
            // invites re-recording over the saved audio; the cause is also what
            // decides whether "tentar novamente" is an honest offer.
            failProcessing(processingErrorCode(cause));
          }
        } else {
          setPhase("ready");
        }
      } catch (cause) {
        const failureCode = cause instanceof Error ? cause.message : "";
        // The row is no longer writable (it was cancelled/failed out of band —
        // e.g. a spent upload id). The AUDIO is safe in IndexedDB, so instead of
        // looping "retry" against a dead row, salvage it into a FRESH recording
        // and re-upload. One attempt only, so a persistent rejection still ends.
        if (!uploadConfirmed && failureCode === "recording_invalid_state" && !salvageAttemptedRef.current) {
          salvageAttemptedRef.current = true;
          const fresh = await beginServerRecording(mintFreshUploadId(), false);
          if (fresh.ok) {
            recordingId.current = fresh.recordingId;
            onChanged?.();
            void upload(blob, duration, mime);
            return;
          }
        }
        if (!uploadConfirmed) {
          await setRecordingState(id, {
            action: "failed",
            failureStage: "upload",
            errorCode: "storage_upload_failed",
          }).catch(() => undefined);
        }
        setError(uploadConfirmed ? t("recorder-processing-error") : t("recorder-error"));
        setPhase("error");
        // The audio is safe locally, but she must learn the send failed even if
        // she already moved on to the next patient.
        markTabAlert(document, t("recorder-alert-tab"));
        notifyCaptureFailure(t("recorder-alert-title"), t("recorder-alert-upload-body"));
        onChanged?.();
      }
    },
    [
      beginServerRecording,
      consultationId,
      failProcessing,
      mintFreshUploadId,
      onChanged,
      orgId,
      persistSession,
      removeSession,
      requestProcessing,
      setRecordingState,
      t,
      uploadTus,
    ],
  );

  /**
   * Opens the microphone BEFORE any server state exists. Ordering matters: a
   * refused permission used to leave an open `recordings` row behind, and that
   * row made every later capture fail with `recording_already_open` — a
   * consultation permanently unable to record. No device, no row.
   */
  const start = async (startTrial = false) => {
    setError(null);
    setMicBlocked(false);
    setProcessingFailure(null);
    setNearSizeLimit(false);
    setCaptureLimit(null);
    clearTabAlert(document);

    let media: MediaStream;
    try {
      media = await navigator.mediaDevices.getUserMedia({ audio: true });
    } catch (cause) {
      // A hard block never prompts again — that needs address-bar instructions,
      // not a generic "check your browser".
      const denied =
        cause instanceof DOMException && (cause.name === "NotAllowedError" || cause.name === "SecurityError");
      setMicBlocked(denied);
      setError(denied ? t("recorder-mic-blocked") : t("recorder-mic-unavailable"));
      setPhase("error");
      return;
    }

    salvageAttemptedRef.current = false;
    let startedRecordingId: string;
    try {
      let uploadId =
        clientUploadId.current ??
        getOrCreateWebRecordingRequest(window.sessionStorage, consultationId, () => crypto.randomUUID());
      clientUploadId.current = uploadId;

      let result = await beginServerRecording(uploadId, startTrial);
      // A stored id can point at a spent capture (a prior cancelled/failed row);
      // mint a fresh one and start clean rather than surfacing a dead end.
      if (!result.ok && result.code === "stale_upload_id") {
        uploadId = mintFreshUploadId();
        result = await beginServerRecording(uploadId, startTrial);
      }

      if (!result.ok) {
        const code = result.code;
        if (code === "consent_required" || code === "audio_consent_required" || code === "ai_consent_required") {
          onRequestConsent?.();
        }
        if (code === "recording_already_open" && result.recordingId) {
          // Surface the blocker WITH its way out instead of a dead-end message.
          setOrphan({ id: result.recordingId, status: "recording", createdAt: new Date().toISOString() });
        }
        setError(
          code === "audio_allowance_exhausted"
            ? t("recorder-limit-body")
            : code === "trial_not_started"
              ? trialParams
                ? t("recorder-trial-body", trialParams)
                : t("recorder-trial-body-generic")
              : code === "recording_already_open"
                ? t("recorder-open-recording")
                : t("recorder-error"),
        );
        setPhase("error");
        media.getTracks().forEach((track) => track.stop());
        void reloadAllowance();
        clearWebRecordingRequest(window.sessionStorage, consultationId);
        clientUploadId.current = null;
        return;
      }
      startedRecordingId = result.recordingId;
    } catch {
      // Ambiguous network/response failures retain the exact idempotency key.
      // A retry can recover a server commit whose response never arrived.
      media.getTracks().forEach((track) => track.stop());
      setError(t("recorder-error"));
      setPhase("error");
      return;
    }

    recordingId.current = startedRecordingId;
    recordingMode.current = mode;
    onChanged?.();

    try {
      stream.current = media;
      chunks.current = [];
      bytesRef.current = 0;
      // A fresh take starts its own sequence at seq 0.
      batcher.current = new ChunkBatcher();
      chunkChain.current = Promise.resolve();
      chunkStartedAtRef.current = new Date().toISOString();
      const mime = bestMime();
      // Speech needs little: a fixed ~32 kbps mono keeps an hour of consultation
      // near ~14 MB — protecting the upload on clinic wifi and the transcription
      // provider's request limits (browser defaults can run 4× larger).
      const recorderOptions: MediaRecorderOptions = { audioBitsPerSecond: 32_000 };
      if (mime) recorderOptions.mimeType = mime;
      const recorder = new MediaRecorder(media, recorderOptions);
      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunks.current.push(event.data);
          bytesRef.current += event.data.size;
          // Persist as we go. In memory, this array WAS the consultation until
          // the take ended — a crashed tab at minute 50 took all of it.
          batcher.current.add(event.data, Date.now());
          if (batcher.current.ready(Date.now())) {
            flushChunks(recorder.mimeType || mime || "audio/webm");
          }
          if (bytesRef.current >= MAX_SIZE_BYTES * 0.9) setNearSizeLimit(true);
          if (bytesRef.current >= MAX_SIZE_BYTES) {
            setCaptureLimit("size");
            stopTimer();
            recorder.stop();
          }
        }
      };
      recorder.onstop = () => {
        stopLevelMeter();
        releaseStream();
        setSessionActive(false);
        const effectiveMime = recorder.mimeType || mime || "audio/webm";
        // Whatever is still held goes down before the final blob is assembled,
        // so a crash between stop() and a completed upload still recovers.
        flushChunks(effectiveMime);
        const blob = new Blob(chunks.current, { type: effectiveMime });
        void upload(blob, secondsRef.current, effectiveMime);
      };
      // Only a PERMANENT device loss ends the capture. `onended` fires when the
      // track is gone for good (unplugged, OS revoked). `onmute` must NOT stop
      // recording — it fires for TRANSIENT conditions (a Bluetooth headset
      // renegotiating, a driver hiccup, the OS muting the track for a moment at
      // capture start) and would drop the session in its first second. A mute
      // that actually persists is caught by the 60s silence watchdog instead.
      media.getAudioTracks().forEach((track) => {
        track.onended = handleCaptureLoss;
      });
      mediaRecorder.current = recorder;
      recorder.start(1000);
      startedAtRef.current = Date.now();
      pausedTotalRef.current = 0;
      pausedAtRef.current = 0;
      secondsRef.current = 0;
      setSeconds(0);
      setPhase("recording");
      setSessionActive(true);
      startLevelMeter(media);
      timer.current = setInterval(() => {
        secondsRef.current = Math.floor((Date.now() - startedAtRef.current - pausedTotalRef.current) / 1000);
        setSeconds(secondsRef.current);
        if (secondsRef.current >= MAX_DURATION_SECONDS && mediaRecorder.current?.state !== "inactive") {
          setCaptureLimit("duration");
          stopTimer();
          mediaRecorder.current?.stop();
        }
      }, 1000);
    } catch {
      stopLevelMeter();
      releaseStream();
      setSessionActive(false);
      let cancelled = false;
      if (recordingId.current) {
        try {
          await setRecordingState(recordingId.current, {
            action: "cancel",
            errorCode: "microphone_unavailable",
          });
          cancelled = true;
        } catch {
          // Keep the request id: the cancellation response may have been lost.
        }
      }
      if (cancelled) {
        clearWebRecordingRequest(window.sessionStorage, consultationId);
        clientUploadId.current = null;
      }
      recordingId.current = null;
      setError(t("recorder-mic-unavailable"));
      setPhase("error");
      onChanged?.();
    }
  };

  /**
   * Explains what is about to happen before the browser's own prompt appears.
   * A bare permission dialog with no context is reflexively dismissed — and a
   * hard "Block" is unrecoverable without address-bar surgery.
   */
  const requestStart = async (startTrial = false) => {
    setError(null);
    if (typeof navigator.permissions?.query === "function") {
      try {
        const status = await navigator.permissions.query({ name: "microphone" as PermissionName });
        if (status.state === "granted") {
          await start(startTrial);
          return;
        }
      } catch {
        // Firefox/Safari may not know this descriptor — fall through to the primer.
      }
    }
    setMicPrimer({ startTrial });
  };

  const pause = () => {
    mediaRecorder.current?.pause();
    stopTimer();
    pausedAtRef.current = Date.now();
    setPhase("paused");
  };
  const resume = () => {
    mediaRecorder.current?.resume();
    // Paused time is excluded from the elapsed clock, so the timer keeps
    // matching the audio that actually exists.
    if (pausedAtRef.current) pausedTotalRef.current += Date.now() - pausedAtRef.current;
    pausedAtRef.current = 0;
    loudAtRef.current = Date.now();
    timer.current = setInterval(() => {
      secondsRef.current = Math.floor((Date.now() - startedAtRef.current - pausedTotalRef.current) / 1000);
      setSeconds(secondsRef.current);
    }, 1000);
    setPhase("recording");
  };
  /**
   * Ask before ending. A take cannot be resumed once stopped — anything after
   * it becomes a SECOND recording, with the merge cost that carries — so a
   * mistap on the floating bar ends the capture of an appointment still in the
   * room. Every other consequential action here confirms; this one, the most
   * expensive, did not.
   */
  const finish = () => setConfirmFinish(true);

  const confirmFinishCapture = () => {
    setConfirmFinish(false);
    stopTimer();
    setSessionActive(false);
    clearTabAlert(document);
    mediaRecorder.current?.stop();
  };
  const retryUpload = () => {
    const pending = pendingBlob.current;
    if (pending) void upload(pending.blob, pending.duration, pending.mime);
  };
  /** Re-run only the AI prep — the audio is already uploaded server-side. */
  const retryProcessing = () => {
    const id = recordingId.current;
    if (!id) return;
    setProcessingFailure(null);
    void requestProcessing(id).catch((cause) => {
      failProcessing(processingErrorCode(cause));
    });
  };
  const confirmTrial = async () => {
    setStartingTrial(true);
    setTrialDialog(false);
    await requestStart(true);
    setStartingTrial(false);
    void reloadAllowance();
  };

  const mmss = `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
  const capturing = phase === "recording" || phase === "paused" || phase === "uploading" || phase === "processing";
  const needsTrial = mode === "ai" && !capturing && allowance?.trialAvailable === true && !allowance.canStart;
  const exhausted =
    mode === "ai" && !capturing && allowance !== null && !allowance.canStart && !allowance.trialAvailable;
  // A failed card and an exhausted allowance both stop capture, but only one of
  // them is solved by buying something. Sending someone with a recused card to
  // a grid of plans is a dead end dressed as a next step, so the blocked state
  // reads its cause from the allowance instead of guessing (migration 0054).
  const paymentBlocked = exhausted && allowance?.reason === "past_due_blocked";
  // A PIX she started was never confirmed and its provisional window closed
  // (migration 0111). Finishing THAT payment is the answer — not the plans grid,
  // and never a trial.
  const paymentUnconfirmed = exhausted && allowance?.reason === "payment_unconfirmed";
  const finishPaymentHref = allowance?.pendingPlanSlug
    ? `/assinatura?plan=${encodeURIComponent(allowance.pendingPlanSlug)}`
    : BILLING_HREF;
  const inGracePeriod = mode === "ai" && allowance?.reason === "past_due_grace";
  const graceLeft = allowance ? graceDaysLeft(allowance) : null;
  const overrunning =
    mode === "ai" &&
    phase === "recording" &&
    allowance !== null &&
    allowance.minutesLimit > 0 &&
    seconds > allowance.minutesRemaining * 60;
  const nearingCaptureLimit = phase === "recording" && (seconds >= MAX_DURATION_SECONDS - 10 * 60 || nearSizeLimit);
  const processingFailed = processingFailure !== null;
  // Every post-upload failure used to read as a temporary outage with a retry
  // button. Two of them are definitive: the provider refused (a retry hits the
  // same wall) and the consent is no longer valid (it needs a different action
  // entirely), so each one states its own cause and its own way out.
  const processingRetryable = processingFailure !== null && isRetryableFailure(processingFailure);
  const processingNeedsConsent = processingFailure !== null && isConsentFailure(processingFailure);
  const processingFailureText =
    processingFailure === null
      ? null
      : processingFailure === "recording_cancelled"
        ? t("recorder-cancelled-body")
        : processingFailure === "provider_rejected"
          ? t("recordings-error-provider-rejected")
          : isConsentFailure(processingFailure)
            ? t("recordings-error-consent")
            : processingFailure === "provider_unavailable"
              ? t("recordings-error-provider-unavailable")
              : processingFailure === "clinical_revision_conflict"
                ? t("recordings-error-revision")
                : processingFailure === "allowance_unavailable" || processingFailure === "audio_allowance_exhausted"
                  ? t("recordings-error-allowance")
                  : // `recorder-ai-failed` is the only copy that promises a new
                    // attempt, so it belongs ONLY to causes a new attempt can fix.
                    // A structural refusal gets the neutral wording the recordings
                    // panel already uses for the same bucket.
                    isRetryableFailure(processingFailure)
                    ? t("recorder-ai-failed")
                    : t("recordings-process-error");
  // Capture always feeds the AI, so both consents are required.
  const hasRequiredConsent = consents?.audio === true && consents.ai;

  useEffect(() => {
    if (!exhausted || upgradePromptViewed.current) return;
    upgradePromptViewed.current = true;
    trackCommercialEvent("upgrade.prompt_viewed", "consultation", "audio");
  }, [exhausted]);

  // Reserve the space instead of vanishing: on a slow connection an absent card
  // reads as "recording is not available here".
  if (consents === null || allowanceLoading) {
    return (
      <Card component="section" aria-label={t("recorder-title")} aria-busy>
        <CardContent className="flex flex-col gap-3">
          <Skeleton variant="text" width={160} height={28} />
          <Skeleton variant="rounded" height={40} className="rounded-2xl" />
          <Skeleton variant="rounded" height={72} className="rounded-2xl" />
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card component="section">
        <CardContent className="flex flex-col gap-3">
          <ConsultationStepHeader
            // No number: recording is one WAY of doing the record step, not a
            // step of its own. Numbering it left the manual anamnesis — the
            // other half of the same step — looking like it was off the path.
            step={undefined}
            icon={<NiMicrophone size="medium" />}
            title={t("recorder-title")}
            hint={t("recorder-step-hint")}
            // Operational detail (server confirmation, plan tier) sits behind an
            // info affordance, anchored to the title it qualifies. On its own
            // line it read as a stray icon belonging to nothing.
            trailing={<InfoHint label={t("recorder-note")} className="ml-auto" />}
          />
          {/* A capture left open by a reload or a refused microphone blocks every
            new one at the server. Never a dead end: state it and offer the exit. */}
          {orphan && (
            <Alert severity="warning" className="neutral bg-background-paper/60! flex flex-col gap-2">
              <Typography variant="body2" className="font-semibold">
                {t("recorder-orphan-title")}
              </Typography>
              <Typography variant="body2" className="text-xs leading-5">
                {t("recorder-orphan-body", { time: new Date(orphan.createdAt).toLocaleTimeString() })}
              </Typography>
              <Button
                variant="contained"
                color="primary"
                size="small"
                className="self-start"
                disabled={discardingOrphan}
                onClick={() => void discardOrphan()}
              >
                {discardingOrphan ? t("saving") : t("recorder-orphan-discard")}
              </Button>
            </Alert>
          )}

          {/* Inside the dunning window everything still works — this says so,
              and says by when, so the first sign of a payment problem is not
              the recorder refusing to start. Hidden while capturing: there is
              a patient in the room and this can wait for the gap between
              appointments. Amber, never red — a billing matter is not clinical
              risk (docs/DESIGN.md). */}
          {inGracePeriod && !capturing && (
            <Alert
              severity="warning"
              className="neutral bg-background-paper/60!"
              action={
                <Button
                  size="small"
                  color="inherit"
                  href={PAYMENT_HREF}
                  onClick={() => trackCommercialEvent("upgrade.prompt_clicked", "consultation", "payment")}
                >
                  {t("recorder-past-due-cta")}
                </Button>
              }
            >
              {graceLeft !== null
                ? t("recorder-past-due-grace", { days: graceLeft })
                : t("recorder-past-due-grace-generic")}
            </Alert>
          )}

          {allowanceError && mode === "ai" ? (
            <Alert
              severity="error"
              className="neutral bg-background-paper/60!"
              action={<Button onClick={() => void reloadAllowance()}>{t("retry")}</Button>}
            >
              {t("recorder-allowance-error")}
            </Alert>
          ) : !hasRequiredConsent ? (
            <>
              {/* Text only: the consent is registered in ONE place, the
                  "Consentimentos" control at the top of the consultation, and
                  this sentence says so. The same button repeated on every card
                  made it unclear which one to press. */}
              <Typography variant="body2" className="text-text-secondary leading-6">
                {consents.audio ? t("recorder-no-ai-consent") : t("recorder-no-consent")}
              </Typography>
            </>
          ) : needsTrial ? (
            <>
              <Typography variant="body2" className="text-text-secondary leading-6">
                {trialParams ? t("recorder-trial-body", trialParams) : t("recorder-trial-body-generic")}
              </Typography>
              <Button variant="contained" color="primary" onClick={() => setTrialDialog(true)} className="self-start">
                {t("recorder-trial-start")}
              </Button>
              <Typography variant="body2" className="text-text-secondary text-xs leading-5">
                {trialNote}
              </Typography>
            </>
          ) : exhausted ? (
            <>
              <Typography variant="body2" className="text-text-secondary leading-6">
                {/* The Pro trial ends on 14 days OR 300 minutes, whichever
                    comes first, so "your minutes ran out" was being shown to
                    someone with 297 of them left — the billing page said as
                    much on the same account. Each cause states itself. */}
                {allowance?.suspended
                  ? t("recorder-suspended-body")
                  : paymentUnconfirmed
                    ? t("recorder-payment-unconfirmed-body")
                    : paymentBlocked
                      ? t("recorder-past-due-body")
                      : allowance?.reason === "trial_over"
                        ? t("recorder-trial-over-body")
                        : t("recorder-limit-body")}
              </Typography>
              {/* A suspension is not hers to resolve, so it gets no action —
                  every other cause gets the one that actually resolves it. */}
              {!allowance?.suspended && (
                <Box className="flex flex-row flex-wrap gap-2">
                  <Button
                    variant="contained"
                    color="primary"
                    href={paymentUnconfirmed ? finishPaymentHref : paymentBlocked ? PAYMENT_HREF : BILLING_HREF}
                    onClick={() =>
                      trackCommercialEvent(
                        "upgrade.prompt_clicked",
                        "consultation",
                        paymentBlocked || paymentUnconfirmed ? "payment" : "audio",
                      )
                    }
                  >
                    {paymentUnconfirmed
                      ? t("recorder-payment-unconfirmed-cta")
                      : paymentBlocked
                        ? t("recorder-past-due-cta")
                        : t("recorder-limit-cta")}
                  </Button>
                  {/* Only for someone already on a paid plan whose cycle ran
                      out: for her, waiting for the renewal and jumping a tier
                      are both worse answers than buying the minutes she needs
                      today (migration 0055). */}
                  {!paymentBlocked && allowance?.packPurchasable && (
                    <Button
                      variant="outlined"
                      color="primary"
                      href={PACK_HREF}
                      onClick={() => trackCommercialEvent("upgrade.prompt_clicked", "consultation", "audio_pack")}
                    >
                      {t("recorder-buy-pack-cta")}
                    </Button>
                  )}
                </Box>
              )}
            </>
          ) : (
            <>
              {(phase === "recording" || phase === "paused") && (
                <Box
                  className={cn(
                    "flex flex-col gap-2 rounded-2xl px-3 py-2.5",
                    phase === "recording" ? "bg-accent-3/12" : "bg-grey-100",
                  )}
                  role="status"
                  aria-live="polite"
                >
                  <Box className="flex flex-row items-center gap-2">
                    <span
                      aria-hidden
                      className={cn(
                        "h-2.5 w-2.5 flex-none rounded-full",
                        phase === "recording" ? "bg-accent-3 animate-pulse" : "bg-grey-500",
                      )}
                    />
                    <Typography variant="body2" className="font-semibold">
                      {phase === "recording" ? t("recorder-recording") : t("recorder-paused")}
                    </Typography>
                    <Typography variant="body2" className="text-text-secondary ml-auto font-mono tabular-nums">
                      {mmss}
                    </Typography>
                  </Box>
                  {/* The level is the only honest proof that sound is arriving —
                    a running clock proves nothing about the microphone. */}
                  {phase === "recording" && (
                    <Box
                      className="bg-grey-100 h-1.5 w-full overflow-hidden rounded-full"
                      role="meter"
                      aria-label={t("recorder-level-label")}
                      aria-valuemin={0}
                      aria-valuemax={100}
                      aria-valuenow={Math.round(level * 100)}
                    >
                      <Box
                        className={cn(
                          "h-full rounded-full transition-all duration-100",
                          silent ? "bg-accent-3" : "bg-primary",
                        )}
                        style={{ width: `${Math.max(2, Math.round(level * 100))}%` }}
                      />
                    </Box>
                  )}
                  {phase === "recording" && silent && (
                    <Typography
                      variant="body2"
                      className="text-accent-3-dark dark:text-accent-3-light text-xs leading-5"
                    >
                      {t("recorder-silence-warning")}
                    </Typography>
                  )}
                </Box>
              )}

              {overrunning && <Alert severity="info">{t("recorder-overrun")}</Alert>}
              {nearingCaptureLimit && <Alert severity="info">{t("recorder-capture-limit-warning")}</Alert>}
              {captureLimit && (
                <Alert severity="info">
                  {captureLimit === "duration"
                    ? t("recorder-capture-limit-duration")
                    : t("recorder-capture-limit-size")}
                </Alert>
              )}
              {/* Said while it matters and gone the moment it stops mattering.
                  The leave guard is released at "Encerrar e enviar", so from
                  here on nothing else would tell her that closing the tab
                  interrupts the upload — or that this page is where the
                  result appears. Amber, not red: nothing is wrong yet. */}
              {(phase === "uploading" || (phase === "processing" && !pollTimedOut)) && (
                <Alert severity="warning" className="neutral bg-background-paper/60!">
                  {t("recorder-keep-open")}
                </Alert>
              )}
              {phase === "uploading" && (
                <Box className="flex flex-col gap-2">
                  <Typography variant="body2" className="text-text-secondary">
                    {t("recorder-uploading")}
                  </Typography>
                  <LinearProgress
                    variant="determinate"
                    value={Math.round(uploadProgress * 100)}
                    aria-label={t("recorder-uploading")}
                  />
                </Box>
              )}
              {phase === "processing" && (
                <Box className="flex flex-col gap-2" role="status" aria-live="polite">
                  <Typography variant="body2" className="text-text-secondary">
                    {t("recorder-processing")}
                  </Typography>
                  <LinearProgress />
                </Box>
              )}
              {/* Processing finished either way — but "pronta para revisão"
                  over a take that was cut short is a complete state reported
                  for a partial one, and only she can judge what the audio
                  actually covers. */}
              {phase === "ready" &&
                (captureInterrupted ? (
                  <Alert severity="warning" icon={<NiCheckSquare />}>
                    {t("recorder-ready-interrupted")}
                  </Alert>
                ) : (
                  <Alert severity="success" icon={<NiCheckSquare />}>
                    {t("recorder-ready")}
                  </Alert>
                ))}
              {/* The capture succeeded; only the AI prep failed. A warning, not an
                  error — nothing was lost. The text is the server's cause, so a
                  definitive refusal never poses as a passing outage. */}
              {processingFailureText && (
                <Alert severity="warning" icon={<NiCheckSquare />}>
                  {processingFailureText}
                </Alert>
              )}
              {pollTimedOut && phase === "processing" && (
                <Alert severity="info">{t("recorder-processing-later")}</Alert>
              )}
              {error && (
                <Alert severity="error">
                  {error}
                  {/* A hard block never prompts again: say exactly where to undo it. */}
                  {micBlocked && (
                    <Typography variant="body2" className="mt-1 text-xs leading-5">
                      {t("recorder-mic-blocked-help")}
                    </Typography>
                  )}
                </Alert>
              )}

              <Box className="flex flex-row flex-wrap gap-2">
                {phase === "idle" && (
                  <Button
                    variant="contained"
                    size="large"
                    fullWidth
                    color="primary"
                    startIcon={<NiMicrophone size="tiny" />}
                    disabled={Boolean(orphan)}
                    onClick={() => void requestStart()}
                  >
                    {t("recorder-start")}
                  </Button>
                )}
                {/* AI prep failed but the audio is saved: offer to retry the prep,
                    never a "record again" that would abandon the saved audio.
                    Only when a retry can actually resolve it — against a refused
                    processing or a revoked consent it is a button that fails
                    every time she presses it. */}
                {processingRetryable && (
                  <Button
                    variant="contained"
                    size="large"
                    fullWidth
                    color="primary"
                    startIcon={<NiCheckSquare size="tiny" />}
                    onClick={retryProcessing}
                  >
                    {t("recorder-ai-retry")}
                  </Button>
                )}
                {/* Consent is the only thing that unblocks this one, so that is
                    the action offered — not a retry into the same refusal. */}
                {processingNeedsConsent && (
                  <Typography variant="body2" className="text-text-secondary text-xs leading-5">
                    {t("recorder-processing-consent-hint")}
                  </Typography>
                )}
                {phase === "error" && !processingFailed && pendingBlob.current && (
                  <Button
                    variant="contained"
                    size="large"
                    fullWidth
                    color="primary"
                    startIcon={<NiMicrophone size="tiny" />}
                    onClick={retryUpload}
                  >
                    {t("recorder-retry-upload")}
                  </Button>
                )}
                {phase === "error" && !processingFailed && !pendingBlob.current && (
                  <Button
                    variant="contained"
                    size="large"
                    fullWidth
                    color="primary"
                    startIcon={<NiMicrophone size="tiny" />}
                    disabled={Boolean(orphan)}
                    onClick={() => void requestStart()}
                  >
                    {t("recorder-start")}
                  </Button>
                )}
                {phase === "ready" && (
                  <Button
                    variant="outlined"
                    size="large"
                    fullWidth
                    color="primary"
                    startIcon={<NiMicrophone size="tiny" />}
                    disabled={Boolean(orphan)}
                    onClick={() => void requestStart()}
                  >
                    {t("recorder-record-again")}
                  </Button>
                )}
                {/* Pause/finish are a PAIR: they split the row evenly instead of
                    each taking a full line, so the card's height does not jump
                    the moment capture starts. */}
                {phase === "recording" && (
                  <>
                    <Button
                      variant="outlined"
                      size="large"
                      color="grey"
                      className="flex-1"
                      startIcon={<NiPause size="tiny" />}
                      onClick={pause}
                    >
                      {t("recorder-pause")}
                    </Button>
                    <Button
                      variant="contained"
                      size="large"
                      color="primary"
                      className="flex-1"
                      startIcon={<NiSquare size="tiny" />}
                      onClick={finish}
                    >
                      {t("recorder-finish")}
                    </Button>
                  </>
                )}
                {phase === "paused" && (
                  <>
                    <Button
                      variant="outlined"
                      size="large"
                      color="grey"
                      className="flex-1"
                      startIcon={<NiMicrophone size="tiny" />}
                      onClick={resume}
                    >
                      {t("recorder-resume")}
                    </Button>
                    <Button
                      variant="contained"
                      size="large"
                      color="primary"
                      className="flex-1"
                      startIcon={<NiSquare size="tiny" />}
                      onClick={finish}
                    >
                      {t("recorder-finish")}
                    </Button>
                  </>
                )}
              </Box>

              {mode === "ai" && allowance && allowance.minutesLimit > 0 && (
                <Box className="flex flex-row items-center gap-1.5">
                  <NiClock
                    size="tiny"
                    aria-hidden
                    className={allowance.percent >= 80 ? "text-accent-3" : "text-text-secondary"}
                  />
                  <Typography
                    variant="body2"
                    className={cn(
                      "text-xs leading-5",
                      allowance.percent >= 80
                        ? "text-accent-3-dark dark:text-accent-3-light font-medium"
                        : "text-text-secondary",
                    )}
                  >
                    {allowance.source === "trial"
                      ? t("recorder-trial-remaining", {
                          minutes: allowance.minutesRemaining,
                          days: trialDaysLeft(allowance) ?? 0,
                        })
                      : t("recorder-remaining", { minutes: allowance.minutesRemaining })}
                  </Typography>
                </Box>
              )}
            </>
          )}

          {/* An alternate capture METHOD for this same step, not a step of its
              own — hidden mid-capture so it never reads as an invitation to
              start a second, simultaneous recording of the same visit. */}
          {!capturing && secondaryCapture}
        </CardContent>

        <Dialog open={trialDialog} onClose={() => setTrialDialog(false)} maxWidth="xs" fullWidth>
          <DialogHeader
            title={t("recorder-trial-title")}
            closeLabel={t("close")}
            onClose={() => setTrialDialog(false)}
          />
          <DialogContent className="flex flex-col gap-2 py-5!">
            <Typography variant="body2" className="text-text-secondary leading-6">
              {trialParams ? t("recorder-trial-explain", trialParams) : t("recorder-trial-explain-generic")}
            </Typography>
            <Typography variant="body2" className="text-text-secondary leading-6">
              {trialNote}
            </Typography>
          </DialogContent>
          <DialogActions>
            <Button color="grey" onClick={() => setTrialDialog(false)} disabled={startingTrial}>
              {t("recorder-trial-cancel")}
            </Button>
            <Button variant="contained" color="primary" onClick={() => void confirmTrial()} disabled={startingTrial}>
              {t("recorder-trial-confirm")}
            </Button>
          </DialogActions>
        </Dialog>

        {/* Context before the browser's own prompt. A bare permission dialog with
          no explanation is reflexively dismissed — and a hard block cannot be
          undone from inside the page. */}
        <Dialog open={micPrimer !== null} onClose={() => setMicPrimer(null)} maxWidth="xs" fullWidth>
          <DialogHeader
            title={t("recorder-mic-primer-title")}
            closeLabel={t("close")}
            onClose={() => setMicPrimer(null)}
          />
          <DialogContent className="flex flex-col gap-2 py-5!">
            <Typography variant="body2" className="text-text-secondary leading-6">
              {t("recorder-mic-primer-body")}
            </Typography>
            <Typography variant="body2" className="text-text-secondary text-xs leading-5">
              {t("recorder-mic-primer-note")}
            </Typography>
          </DialogContent>
          <DialogActions>
            <Button color="grey" onClick={() => setMicPrimer(null)}>
              {t("recorder-mic-primer-cancel")}
            </Button>
            <Button
              variant="contained"
              color="primary"
              onClick={() => {
                const pending = micPrimer;
                setMicPrimer(null);
                void start(pending?.startTrial ?? false);
              }}
            >
              {t("recorder-mic-primer-confirm")}
            </Button>
          </DialogActions>
        </Dialog>

        {/* Names what ending actually costs: the take cannot be resumed, so a
            mistap here ends the recording of an appointment still in progress. */}
        <Dialog open={confirmFinish} onClose={() => setConfirmFinish(false)} maxWidth="xs" fullWidth>
          <DialogHeader
            title={t("recorder-finish-confirm-title")}
            closeLabel={t("close")}
            onClose={() => setConfirmFinish(false)}
          />
          <DialogContent className="flex flex-col gap-2 py-5!">
            <Typography variant="body2" className="text-text-secondary leading-6">
              {t("recorder-finish-confirm-body", { elapsed: mmss })}
            </Typography>
          </DialogContent>
          <DialogActions>
            <Button color="grey" onClick={() => setConfirmFinish(false)}>
              {t("recorder-finish-confirm-cancel")}
            </Button>
            <Button variant="contained" color="primary" onClick={confirmFinishCapture}>
              {t("recorder-finish-confirm-ok")}
            </Button>
          </DialogActions>
        </Dialog>
      </Card>

      {/* Capture state follows her down the page. The sidebar card scrolls away
        during a 50-minute session, and losing sight of "am I recording?" is
        exactly how a consultation goes unrecorded. */}
      {(phase === "recording" || phase === "paused") && (
        <Box
          // `sm:w-auto` sizes the pill to its content, and a `basis-full` chip
          // still contributes its full text to that intrinsic width — measured
          // at 380px without the warning and 854px with it, so the pill more
          // than doubled across the consultation. Capping the width keeps the
          // chip on its own line without letting it stretch the bar.
          className="bg-background-paper border-grey-100 fixed inset-x-3 bottom-3 z-50 flex flex-row flex-wrap items-center gap-3 rounded-2xl border px-4 py-2.5 shadow-lg sm:inset-x-auto sm:right-5 sm:bottom-5 sm:w-auto sm:max-w-96"
          role="status"
          aria-live="polite"
          aria-label={t("recorder-floating-label")}
        >
          <span
            aria-hidden
            className={cn(
              "h-2.5 w-2.5 flex-none rounded-full",
              phase === "recording" ? (silent ? "bg-accent-3" : "bg-accent-3 animate-pulse") : "bg-grey-500",
            )}
          />
          <Typography variant="body2" className="font-semibold">
            {phase === "recording" ? t("recorder-recording") : t("recorder-paused")}
          </Typography>
          <Typography variant="body2" className="font-mono tabular-nums">
            {mmss}
          </Typography>
          {phase === "recording" && (
            <Box className="bg-grey-100 h-1.5 w-16 overflow-hidden rounded-full" aria-hidden>
              <Box
                className={cn("h-full rounded-full transition-all duration-100", silent ? "bg-accent-3" : "bg-primary")}
                style={{ width: `${Math.max(2, Math.round(level * 100))}%` }}
              />
            </Box>
          )}
          {/* The card these warnings live in is out of the viewport during a
              50-minute consultation, so the automatic cut at the technical limit
              used to arrive unannounced. A short version travels with the pill —
              the full explanation stays in the card, this only has to be seen.
              Never red: neither warning interrupts the capture in progress
              (PRD §5.8); the nearer, harder ceiling wins when both apply. */}
          {(nearingCaptureLimit || overrunning) && (
            <Typography
              variant="body2"
              className="bg-accent-3/12 text-accent-3-dark dark:text-accent-3-light basis-full rounded-lg px-2 py-1 text-xs leading-5 font-medium"
            >
              {nearingCaptureLimit ? t("recorder-capture-limit-short") : t("recorder-overrun-short")}
            </Typography>
          )}
          <Box className="flex flex-row gap-1">
            <Button
              variant="text"
              color="grey"
              size="small"
              startIcon={phase === "recording" ? <NiPause size="tiny" /> : <NiMicrophone size="tiny" />}
              onClick={phase === "recording" ? pause : resume}
            >
              {phase === "recording" ? t("recorder-pause") : t("recorder-resume")}
            </Button>
            <Button
              variant="contained"
              color="primary"
              size="small"
              startIcon={<NiSquare size="tiny" />}
              onClick={finish}
            >
              {t("recorder-finish")}
            </Button>
          </Box>
        </Box>
      )}
    </>
  );
}
