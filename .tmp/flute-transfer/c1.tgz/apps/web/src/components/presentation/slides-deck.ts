import type { SlideData } from "./types";

/**
 * The deck itself: every slide, with its TELEPROMPTER — `script`, `scriptZh`,
 * `stageNote`, `optionalCut`, `optionalCutZh` and each media `productionNote`.
 *
 * A module of its own on purpose (split out of slides-data.ts on 2026-09-26).
 * slides-data.ts holds what is PROJECTED and is imported by slide-views.tsx, the
 * renderer every deck page ships to the browser — including the public deck
 * (/palestra/publica), which must never carry the speaker notes. Only the stage
 * deck (slide-deck.tsx), the PDF export (deck-export.tsx) and the SERVER page of
 * the public deck import this file; the public deck strips the notes on the
 * server before anything reaches the client.
 */
export const SLIDES_DATA: SlideData[] = [
  {
    key: "cover",
    roteiroSlide: 1,
    block: 1,
    blockTitle: { pt: "Abertura e apresentação", zh: "开场与介绍" },
    timeRange: "0:00–3:00",
    kicker: { pt: "Congresso de MTC · ALAR / Xinjiang, China · 2026", zh: "中医药大会 · ALAR / 中国新疆 · 2026" },
    title: { pt: "Do papel ao prontuário inteligente", zh: "从纸质病历到智能病历" },
    subtitle: {
      pt: "A medicina chinesa no Brasil e a jornada do MedChina",
      zh: "中医药在巴西的发展与 MedChina 的历程",
    },
    stageNote: "Slide 1 · Título da palestra + bandeiras do Brasil e da China.",
    script: `Boa tarde.

Quero agradecer aos organizadores deste evento por esta preciosa oportunidade e a todos os especialistas e colegas pela atenção e pela troca.

Para uma acupunturista brasileira, estar aqui não é apenas uma viagem de trabalho. É uma peregrinação.

Hoje quero compartilhar uma história que une três elementos: a trajetória da acupuntura no Brasil, minha trajetória como terapeuta e o nascimento do MedChina AI.`,
    scriptZh: `下午好。

感谢本次大会的主办方给予这一宝贵的机会，也感谢在座各位专家与同道的聆听与交流。

对一位巴西针灸师而言，站在这里不只是一次工作旅行，而是一次朝圣。

今天我想讲一个故事，它把三条线索连在一起：针灸在巴西的历程、我作为治疗师的历程，以及 MedChina AI 的诞生。`,
  },
  {
    key: "founders",
    roteiroSlide: 2,
    block: 1,
    blockTitle: { pt: "Abertura e apresentação", zh: "开场与介绍" },
    timeRange: "0:00–3:00",
    kicker: { pt: "Quem constrói o MedChina", zh: "MedChina 的建设者" },
    title: { pt: "Sabedoria milenar e engenharia moderna", zh: "千年智慧与现代工程" },
    subtitle: { pt: "Três histórias que, na verdade, são uma só", zh: "三个故事，其实是同一个故事" },
    stageNote:
      "Slide 2 · Foto dos fundadores + logo MedChina. Fotos reais em /images/palestra/ substituem os monogramas.",
    script: `Sou Debora Giovanella, fundadora do MedChina e terapeuta de medicina chinesa desde 2017, com formação em shiatsu e em acupuntura. Antes disso, foram 25 anos em gestão de marketing e vendas. É a direção clínica do produto que eu conduzo.

Meu sócio, Bruno Santana, é engenheiro de software com mais de 15 anos de experiência e lidera toda a tecnologia do MedChina.

Sabedoria milenar e engenharia moderna: é dessa soma que nasce tudo o que vou mostrar hoje.

Vamos começar pelo princípio.`,
    scriptZh: `我是 Debora Giovanella，MedChina 的创始人，自 2017 年起从事中医治疗，接受过指压与针灸的专业训练。在此之前，我有二十五年市场与销售管理的经历。产品的临床方向由我主持。

我的合伙人 Bruno Santana 是软件工程师，从业十五年以上，全面负责 MedChina 的技术。

千年的智慧，加上现代的工程：今天我要讲的一切，正是从这一结合中生长出来的。

让我们从头说起。`,
  },
  {
    key: "timeline",
    roteiroSlide: 3,
    block: 2,
    blockTitle: { pt: "Dois séculos de agulhas no Brasil", zh: "巴西的两百年银针" },
    timeRange: "3:00–5:30",
    kicker: { pt: "1808 → 2026", zh: "1808 → 2026" },
    title: { pt: "218 anos de agulhas em solo brasileiro", zh: "银针在巴西土地上的218年" },
    subtitle: {
      pt: "De Macau à regulamentação da profissão",
      zh: "从澳门医者到职业规范化",
    },
    stageNote: "Slide 3 · Linha do tempo: 1808 → 2026.",
    optionalCut: `[CORTE OPCIONAL] Quem quebrou esse isolamento foi um personagem improvável: Friedrich Spaeth, um fisioterapeuta nascido em Luxemburgo, que fugiu do nazismo, estudou acupuntura na Alemanha e se naturalizou brasileiro. Em 1958, Spaeth começou a ensinar acupuntura no Rio de Janeiro e em São Paulo. Naquele mesmo ano nasceu a Sociedade Brasileira de Acupuntura. É esse o marco do ensino formal da medicina chinesa no meu país.`,
    optionalCutZh: `【可选段落】打破这一隔绝的，是一位意想不到的人物：Friedrich Spaeth，生于卢森堡的理疗师，为躲避纳粹而出走，在德国研习针灸，后入籍巴西。1958 年，他开始在里约热内卢与圣保罗教授针灸。同年，巴西针灸学会成立。这就是中医在我国正式教学的开端。`,
    script: `Existem registros de acupuntura chinesa no Brasil há 218 anos.

Os primeiros relatos mencionam acupunturistas vindos de Macau em 1808, junto à corte portuguesa que havia se transferido para o Brasil.

Mas havia uma grande barreira: o idioma.

Os mestres orientais não conseguiam ensinar em português. Durante mais de um século, a acupuntura permaneceu principalmente dentro das colônias de imigrantes.

E, mesmo assim, ela cresceu.`,
    scriptZh: `中国针灸传入巴西，有文字可考已有 218 年。

最早的记载提到 1808 年随迁往巴西的葡萄牙宫廷而来的澳门针灸师。

但横亘在前的是一道大障碍：语言。

东方的师父无法用葡萄牙语授业。此后一个多世纪，针灸主要留在移民聚居的社群之内。

即便如此，它仍然生长。`,
  },
  {
    key: "law",
    roteiroSlide: 4,
    block: 3,
    blockTitle: { pt: "A lei que esperamos por 22 anos", zh: "等待了22年的立法" },
    timeRange: "5:30–9:30",
    kicker: { pt: "Um novo profissional está nascendo", zh: "一种新的专业身份正在诞生" },
    title: { pt: "12 de janeiro de 2026 · Lei 15.345", zh: "2026年1月12日 · 第15345号法律" },
    subtitle: {
      pt: "A regulamentação da profissão de acupunturista no Brasil",
      zh: "针灸师职业在巴西的立法规范",
    },
    stageNote: "Slide 4 · 12 de janeiro de 2026 — Lei 15.345.",
    optionalCut: `[CORTE OPCIONAL] A lei não resolveu tudo, e é honesto dizer isso. Ainda não temos um conselho profissional próprio nem diretrizes nacionais de formação. A graduação superior em acupuntura ainda é rara no país, então a porta de entrada mais usada será a comprovação dos cinco anos de prática. Dois pontos do texto foram vetados, entre eles o que permitia o exercício por técnicos de nível médio, um veto negociado justamente para valorizar a formação superior. E nem todos comemoraram: o Conselho Federal de Medicina segue entendendo a acupuntura como ato médico, enquanto os conselhos de fisioterapia, enfermagem e farmácia celebraram a conquista e já publicam as suas normas. O debate continua. Mas agora ele acontece dentro de uma moldura legal.`,
    optionalCutZh: `【可选段落】这部法律并没有解决所有问题，这一点应当诚实地说明。我们还没有自己的职业委员会，也没有全国统一的培养准则。针灸的本科教育在巴西仍然稀少，因此最常见的入行途径将是五年从业经历的证明。法案有两处被否决，其中包括允许中等技术层次人员执业的条款——这一否决正是为了抬升专业培养的门槛而达成的。也并非所有人都在庆祝：联邦医学委员会仍将针灸视为医疗行为，而理疗、护理与药学委员会则对这一进展表示欢迎，并已陆续发布各自的规范。争论仍在继续，但如今它发生在一个法律的框架之内。`,
    script: `Em 12 de janeiro de 2026, segundo a trajetória apresentada nesta palestra, foi sancionada a Lei 15.345, que regulamenta a profissão de acupunturista no Brasil.

Assim, 218 anos depois das primeiras referências à presença da acupuntura chinesa no Brasil, a profissão entra em um novo momento: com mais reconhecimento, mas também com mais responsabilidade e deveres.`,
    scriptZh: `依据本次演讲所梳理的历程：2026 年 1 月 12 日，巴西颁布第 15345 号法律，对针灸师这一职业作出立法规范。

于是，在中国针灸传入巴西的最早记载之后 218 年，这一职业进入新的阶段：获得更多承认，也承担更多责任与义务。`,
  },
  {
    key: "milestones",
    roteiroSlide: 5,
    block: 2,
    blockTitle: { pt: "Dois séculos de agulhas no Brasil", zh: "巴西的两百年银针" },
    timeRange: "9:30–13:00",
    kicker: { pt: "Marcos institucionais", zh: "制度里程碑" },
    title: { pt: "A entrada na saúde pública", zh: "进入公共卫生体系" },
    subtitle: {
      pt: "1988 SUS · 1995 conselhos · 2006 PNPIC · 2018 prática multiprofissional",
      zh: "1988 纳入SUS · 1995 专业委员会 · 2006 PNPIC · 2018 多专业实践",
    },
    stageNote: "Slide 5 · Marcos: 1988 SUS · 1995 conselhos · 2006 PNPIC.",
    script: `Essa lei não nasceu do nada. Muito antes dela, a acupuntura já tinha conquistado espaço na saúde pública.

Em 1988, a acupuntura entrou na rede pública de saúde, inicialmente restrita à aplicação por médicos.

Em 1995, o Conselho Federal de Medicina a reconheceu como especialidade médica, e os conselhos de enfermagem, fisioterapia e biomedicina fizeram o mesmo em seus territórios. Foram quase três décadas de disputa sobre uma única pergunta: quem pode segurar a agulha?

Em 2006, a Política Nacional de Práticas Integrativas abriu o sistema público aos profissionais não médicos.

E em 2018, a acupuntura foi consolidada como prática multiprofissional no Sistema Único de Saúde, o SUS.`,
    scriptZh: `这部法律并非凭空而来。在此之前很久，针灸已在公共卫生体系中赢得了位置。

1988 年，针灸进入公立医疗网络，最初仅限医师施行。

1995 年，联邦医学委员会将其确认为医学专科；护理、理疗与生物医学各委员会也在各自领域作出同样认定。随之而来的是近三十年的争讼，争的只有一个问题：谁可以持针？

2006 年，《国家整合与补充医疗实践政策》向非医师专业人员开放了公立系统。

2018 年，针灸在巴西统一公共卫生体系（SUS）中正式确立为多专业实践。`,
  },
  {
    key: "sus-numbers",
    roteiroSlide: 6,
    block: 2,
    blockTitle: { pt: "Dois séculos de agulhas no Brasil", zh: "巴西的两百年银针" },
    timeRange: "9:30–13:00",
    kicker: { pt: "Números do SUS e do setor privado", zh: "公共体系与私立市场的数据" },
    title: { pt: "A dimensão da acupuntura no Brasil", zh: "针灸在巴西的规模" },
    subtitle: {
      pt: "A prática integrativa mais usada em toda a rede pública brasileira",
      zh: "巴西公立医疗系统中应用最广的整合疗法",
    },
    stageNote: "Slide 6 · Números do SUS.",
    script: `E o que aconteceu quando o sistema público abriu as portas? Os números respondem.

A acupuntura é a prática integrativa mais usada no sistema público brasileiro. Na década encerrada em 2018, foram mais de cinco milhões de sessões. Em 2024, foram 1,1 milhão de sessões em um único ano.

As práticas integrativas chegaram a 83% dos municípios brasileiros.

E somando quatro décadas de difusão, as estimativas apontam que entre 20 e 35 milhões de brasileiros já se trataram com acupuntura — algo entre um em cada dez e um em cada seis habitantes do país.

O Brasil é, possivelmente, um dos maiores territórios de medicina chinesa fora da Ásia. E agora que essa prática tem uma lei, quem honra essa ciência precisa de ferramentas à altura dela.`,
    scriptZh: `公立系统敞开大门之后发生了什么？数字可以回答。

针灸是巴西公立系统中应用最广的整合疗法。截至 2018 年的十年间，诊疗超过五百万人次；2024 年一年即达 110 万人次。

整合医疗实践已覆盖巴西 83% 的市镇。

综合四十年的传播，估算有两千万至三千五百万巴西人接受过针灸治疗——相当于每十人至每六人中就有一人。

巴西可能是亚洲之外最大的中医版图之一。如今这门实践有了法律，敬重这门学问的人，也需要与之相称的工具。`,
  },

  {
    key: "cultures",
    roteiroSlide: 7,
    block: 4,
    blockTitle: { pt: "O paciente e o terapeuta brasileiros", zh: "巴西的患者与治疗师" },
    timeRange: "13:00–16:00",
    kicker: { pt: "Como é atender MTC no Brasil", zh: "在巴西行医是怎样的" },
    title: { pt: "Brasil e China: duas culturas de tratamento", zh: "巴西与中国：两种诊疗文化" },
    subtitle: {
      pt: "Frequência, solidão no consultório e a exigência de um registro impecável",
      zh: "就诊频次、独立执业，以及对病历近乎苛刻的要求",
    },
    stageNote: "Slide 7 · Brasil e China: duas culturas de tratamento.",
    script: `Aqui na China, um tratamento de acupuntura pode ser diário, e a frequência faz parte da lógica terapêutica.

No Brasil, é comum que o paciente faça uma sessão por semana.

Por isso, o registro clínico precisa ser muito bem feito. Uma semana depois, é difícil recuperar de memória todos os detalhes de uma consulta.

Muitos acupunturistas trabalham sozinhos, sem hospital-escola, residência ou um colega mais experiente ao lado para discutir um caso difícil.

Foi pensando nesse profissional que o MedChina nasceu: para oferecer estrutura de registro, segurança de dados e apoio ao raciocínio clínico.`,
    scriptZh: `在中国，针灸治疗可以每天进行，这种频次本身就是治法的一部分。

在巴西，患者通常一周一次。

正因如此，临床记录必须做得扎实。相隔一周，凭记忆很难还原一次诊疗的全部细节。

许多针灸师独自执业，没有教学医院、没有规培，身边也没有更资深的同道可以一起讨论疑难病案。

MedChina 正是为这样的专业人员而生：提供记录的结构、数据的安全，以及临床推理的辅助。`,
  },
  {
    key: "paper",
    roteiroSlide: 8,
    block: 5,
    blockTitle: { pt: "Do papel ao MedChina", zh: "从纸质病历到 MedChina" },
    timeRange: "16:00–22:30",
    kicker: { pt: "A gênese do projeto", zh: "项目的缘起" },
    title: { pt: "Começou numa ficha de papel", zh: "始于一张纸卡" },
    subtitle: {
      pt: "2017–2019: a busca por um sistema que falasse a nossa língua",
      zh: "2017–2019：寻找一套“说我们语言”的系统",
    },
    stageNote: "Slide 8 · Foto ou imagem de fichas de papel.",
    script: `Em 2017, na minha primeira formação como terapeuta, comecei a registrar tudo desde o primeiro paciente: dados, queixa e tratamento.

Tudo em fichas de papel.

Eu não encontrava no mercado um prontuário desenvolvido para a lógica da medicina chinesa. Faltavam elementos como anamnese energética, avaliação de língua e pulso, pontos e meridianos.

Foi então que decidi criar um sistema de prontuário eletrônico para acupunturistas brasileiros.

Eu ainda não tinha dinheiro, experiência clínica acumulada nem conhecia todas as necessidades de um acupunturista.

Mas tinha uma ideia e um propósito.`,
    scriptZh: `2017 年，在我第一次接受治疗师培训时，我就从第一位患者起记录一切：资料、主诉与治疗。

全部写在纸卡上。

市面上找不到一份依中医思路设计的病历。缺少的正是气血能量的问诊、舌象与脉象的评估、腧穴与经络。

于是我决定，为巴西的针灸师做一套电子病历系统。

那时我既没有资金，也没有积累起来的临床经验，更不了解一位针灸师的全部需要。

但我有一个想法，和一个目标。`,
  },
  {
    key: "congress",
    roteiroSlide: 9,
    block: 5,
    blockTitle: { pt: "Do papel ao MedChina", zh: "从纸质病历到 MedChina" },
    timeRange: "16:00–22:30",
    kicker: { pt: "União na adversidade da pandemia", zh: "疫情之中的守望相助" },
    title: { pt: "A semente da comunidade: 2020", zh: "社群的种子：2020年" },
    subtitle: {
      pt: "1º Congresso Práticas da Sabedoria Milenar — online e gratuito",
      zh: "首届“千年智慧实践”大会——线上、免费",
    },
    stageNote: "Slide 9 · Congresso Práticas da Sabedoria Milenar — junho de 2020.",
    script: `Então chegou 2020 e veio a pandemia.

Milhares de colegas ficaram sem pacientes e sem saber quando poderiam voltar a trabalhar.

Pensei: se não podíamos atender, poderíamos aprender juntos.

Em junho de 2020, criei o Congresso Práticas da Sabedoria Milenar, totalmente online e gratuito.

Foi com esse trabalho que consegui arrecadar os recursos para criar e desenvolver o MedChina.

Ainda em 2020, contratei o programador. A tecnologia começou a nascer.`,
    scriptZh: `接着是 2020 年，疫情来了。

成千上万的同行没有了患者，也不知道何时才能重新工作。

我想：既然不能出诊，我们可以一起学习。

2020 年 6 月，我创办了"千年智慧实践大会"，全程线上、完全免费。

正是这项工作让我筹到了创建与开发 MedChina 的资源。

也是在 2020 年，我聘请了程序员。技术开始萌芽。`,
  },
  {
    key: "survey",
    roteiroSlide: 10,
    block: 5,
    blockTitle: { pt: "Do papel ao MedChina", zh: "从纸质病历到 MedChina" },
    timeRange: "16:00–22:30",
    kicker: { pt: "Evidência antes do produto", zh: "先有实证，再有产品" },
    title: { pt: "A dor real em quatro números", zh: "四个数据揭示真实痛点" },
    subtitle: {
      pt: "Fevereiro de 2021 · pesquisa sobre a base de 3.800 acupunturistas do congresso",
      zh: "2021年2月 · 面向3800名与会针灸师的问卷调研",
    },
    stageNote: "Slide 10 · Pesquisa de fevereiro de 2021 — os quatro números.",
    script: `Em fevereiro de 2021, fizemos uma pesquisa com a base de 3.800 acupunturistas qualificados que haviam participado do congresso.

Os resultados mostraram uma necessidade praticamente universal e pouca oferta de soluções específicas.

A partir dessa pesquisa, construímos o MedChina, um software de prontuários e gestão de consultórios dedicado aos acupunturistas do Brasil.`,
    scriptZh: `2021 年 2 月，我们面向参加过大会的 3800 位合格针灸师做了一次调研。

结果显示：需求几乎是普遍的，而针对性的解决方案却很少。

基于这项调研，我们建成了 MedChina——一套面向巴西针灸师的病历与诊所管理软件。`,
  },
  {
    key: "version-one",
    roteiroSlide: 11,
    block: 5,
    blockTitle: { pt: "Do papel ao MedChina", zh: "从纸质病历到 MedChina" },
    timeRange: "16:00–22:30",
    kicker: { pt: "Validação orgânica", zh: "自然增长的验证" },
    title: { pt: "A primeira versão e o compromisso da gratuidade", zh: "首个版本与免费的承诺" },
    subtitle: {
      pt: "2021–2023: mil usuários orgânicos e o início da versão 2.0",
      zh: "2021–2023：一千名自然增长用户与 2.0 版的启动",
    },
    stageNote:
      "Slide 11 · Linha do tempo da empresa 2020–2023 + [TELAS] 3 ou 4 capturas da v1 (cadastro, agenda, anamnese, financeiro) — narrar sobre as imagens. Arquivos em /images/palestra/v1-*.webp.",
    script: `A primeira versão foi lançada em agosto de 2021, com a lógica da medicina chinesa e conteúdo de MTC dentro do sistema.

A anamnese guiada era o coração da plataforma.

Um ano depois, tínhamos mil usuários na versão gratuita, sem propaganda paga.

Decidimos manter uma versão gratuita porque nossa missão é contribuir para elevar o registro clínico da profissão, e não apenas atender quem pode pagar.`,
    scriptZh: `第一版于 2021 年 8 月上线，系统内即依中医的思路，并载有中医内容。

引导式问诊是这个平台的核心。

一年之后，免费版已有一千名用户，没有投放任何付费广告。

我们决定保留免费版，因为我们的使命是帮助提升这一职业的临床记录水平，而不只是服务付得起费用的人。`,
  },
  {
    key: "platform-today",
    roteiroSlide: 12,
    block: 5,
    blockTitle: { pt: "Do papel ao MedChina", zh: "从纸质病历到 MedChina" },
    timeRange: "16:00–22:30",
    kicker: { pt: "A plataforma hoje", zh: "今日的平台" },
    title: { pt: "O MedChina em números", zh: "MedChina 的实际数据" },
    subtitle: {
      pt: "Uma comunidade construída desde 2021, sem mídia paga",
      zh: "自2021年积累的专业社群，未投放付费广告",
    },
    stageNote:
      "Slide 12 · Números atuais. Os valores exibidos vêm do banco da plataforma anterior (1.046 cadastros, 222 pagantes). CONFERIR NO DIA: puxar os totais atuais de produção antes da palestra e atualizar PLATFORM_STATS.",
    script: `Hoje, são 1.046 profissionais cadastrados na plataforma e 222 deles já assinaram planos pagos.

Em 2026, voltamos com mais recursos e mais tecnologia — justamente no ano em que a profissão de acupunturista foi reconhecida no Brasil.`,
    scriptZh: `如今，平台上已有 1046 位注册专业人员，其中 222 位订阅了付费方案。

2026 年，我们带着更多资源与技术回来——恰好是针灸师这一职业在巴西获得承认的那一年。`,
  },
  {
    key: "motto",
    roteiroSlide: 13,
    block: 7,
    blockTitle: { pt: "O prontuário que escuta", zh: "会倾听的病历" },
    timeRange: "22:30–34:30",
    kicker: { pt: "O que rouba a atenção do terapeuta", zh: "什么夺走了医者的专注" },
    title: { pt: "Atenda olhando para o paciente", zh: "目视患者，全心诊疗" },
    subtitle: { pt: "O MedChina organiza o restante", zh: "其余的记录，交给 MedChina" },
    stageNote:
      'Slide 13 · MedChina AI — "Atenda olhando para o paciente. O MedChina organiza o restante." O vídeo da consulta ' +
      "começa sozinho, sem som, e roda em loop à direita: fale por cima, não espere por ele e não o aponte como demonstração.",
    script: `E é nesse novo momento, com a profissão regulamentada, que nasce o MedChina AI.

O MedChina de hoje nasceu de uma pergunta simples: o que rouba a atenção do terapeuta durante a consulta?

O computador. A tela. A digitação.

Enquanto registra, o profissional pode perder contato visual, fragmentar a escuta e levar trabalho para casa.

O MedChina AI foi criado para devolver essa atenção ao paciente.

Deixem-me levar vocês para dentro de uma consulta. É o que está acontecendo nesta tela, em velocidade acelerada.`,
    scriptZh: `正是在这个新的时刻，在职业获得立法规范之际，MedChina AI 诞生了。

今天的 MedChina 起于一个朴素的问题：在诊疗中，是什么夺走了医者的专注？

是电脑。是屏幕。是打字。

一边记录，专业人员就可能失去目光的交流，打断倾听，还要把工作带回家。

MedChina AI 就是为把这份专注还给患者而做的。

请让我带各位走进一次诊疗。屏幕上正在发生的就是它，以加速的方式播放。`,
    media: {
      kind: "ambient",
      label: {
        pt: "Uma consulta registrada no MedChina, em velocidade acelerada",
        zh: "一次在 MedChina 中完成的诊疗记录，加速播放",
      },
      sourceUrl: "/videos/palestra/consulta-acelerada.mp4",
      // 0:30 of the clip: filled anamnesis fields with their provenance, next
      // to the hypotheses panel that asks for clinical validation.
      poster: "/videos/palestra/consulta-acelerada-poster.jpg",
      // The picture is 1920x879 inside a 1920x1080 file (100px of black baked
      // in above, 101 below). 872 rather than 879 so the crop clears the band
      // with a few pixels to spare instead of leaving a dark hairline.
      aspect: "1920 / 872",
      caption: {
        pt: "Consulta registrada na plataforma · velocidade acelerada",
        zh: "平台中的诊疗记录 · 加速播放",
      },
      standby: { pt: "Uma consulta, do áudio à anamnese", zh: "一次诊疗：从录音到问诊" },
      productionNote:
        "Loop muto, sem controles, reinicia a cada entrada no slide. Arquivo: apps/web/public/videos/palestra/consulta-acelerada.mp4 (1920×1080 com tarja preta embutida, imagem útil 1920×879, 55s, 17 MB).",
    },
  },
  {
    key: "flow",
    roteiroSlide: 14,
    block: 7,
    blockTitle: { pt: "O prontuário que escuta", zh: "会倾听的病历" },
    timeRange: "22:30–34:30",
    kicker: { pt: "Uma consulta, do começo ao fim", zh: "一次完整的诊疗" },
    title: { pt: "Antes, durante e depois da consulta", zh: "诊前、诊中、诊后" },
    subtitle: {
      pt: "O que antes tomava uma hora do dia acontece enquanto ela atende",
      zh: "过去每天要花一小时的事，如今在诊疗中即已完成",
    },
    stageNote: "Slide 14 · O fluxo: antes, durante e depois da consulta. Telas reais do sistema atual.",
    script: `Durante a consulta, com o consentimento do paciente, o celular ou computador pode capturar o áudio.

O profissional pode olhar, escutar, observar e examinar.

Depois, o sistema transcreve a conversa, separa a fala do profissional e do paciente e organiza a anamnese.

São estruturados dados como queixa principal, história atual, sono, energia, alimentação, digestão, aspectos emocionais e avaliação pela medicina chinesa.`,
    scriptZh: `诊疗过程中，在患者同意的前提下，手机或电脑可以采集录音。

专业人员因此可以注视、倾听、观察与诊察。

其后，系统转写对话，区分医者与患者的话语，并整理问诊。

主诉、现病史、睡眠、精力、饮食、消化、情志，以及中医的辨证内容，都会被结构化地记录下来。`,
  },
  {
    key: "traceability",
    roteiroSlide: 15,
    block: 7,
    blockTitle: { pt: "O prontuário que escuta", zh: "会倾听的病历" },
    timeRange: "22:30–34:30",
    kicker: { pt: "Respeito pela clínica", zh: "对临床的敬重" },
    title: { pt: "Anamnese preenchida com origem rastreável", zh: "可溯源的结构化问诊" },
    subtitle: {
      pt: "Nada aparece no prontuário sem que se possa verificar de onde saiu",
      zh: "凡入病历，皆可回溯其出处",
    },
    stageNote: "Slide 15 · Anamnese preenchida com origem rastreável.",
    script: `Mas há algo que considero fundamental: cada informação preenchida guarda sua origem, permitindo ao profissional ouvir o trecho correspondente do áudio.

Se o paciente não informou alguma coisa, o sistema não transforma silêncio em resposta negativa. O campo permanece como “não informado”.

O sistema também pode apontar lacunas, contradições e mudanças em relação ao histórico.`,
    scriptZh: `但有一点我认为至关重要：每一条填入的信息都保留其出处，专业人员可以据此听到录音中对应的片段。

如果患者没有提到某件事，系统不会把沉默变成否定的回答。该字段保持为"未告知"。

系统还可以指出缺漏、矛盾，以及与既往病史相比发生的变化。`,
  },
  {
    key: "guarantees",
    block: 7,
    blockTitle: { pt: "O prontuário que escuta", zh: "会倾听的病历" },
    timeRange: "22:30–34:30",
    kicker: { pt: "O que o software confere sozinho", zh: "软件自行核验之事" },
    title: { pt: "Quatro garantias que não dependem do modelo", zh: "四项不依赖模型的保障" },
    subtitle: {
      pt: "Depois que a IA responde, regras programadas conferem o resultado",
      zh: "AI 给出结果之后，由既定规则逐条核验",
    },
    stageNote:
      "Slide novo, fora do roteiro impresso · responde a pergunta 1 da organização do congresso. Se o tempo apertar, é o corte mais barato do Bloco 7: o conteúdo inteiro volta no anexo, depois do encerramento.",
    script: `Há uma etapa aqui que eu preciso mostrar, porque é o que nos diferencia.

Depois que o modelo responde, não é a inteligência artificial que confere o resultado. É o software.

São quatro regras programadas.

Todo dado corresponde à fala real. Cada valor traz a frase, o minuto e quem falou, e o sistema procura essa frase na transcrição: se ela não estiver lá, o valor é marcado como não confirmado. Uma citação inventada é pior do que nenhuma, porque ela fabrica prova.

Exame de medicina chinesa só vale na voz do profissional. Língua, pulso, palpação e padrão só entram quando ditados por ele; um achado atribuído à fala do paciente é descartado.

Silêncio nunca vira registro. O que ninguém disse fica vazio, como não informado.

E os temas sensíveis, como medicamentos, gestação, anticoagulantes, marca-passo, cirurgias e alergias, sempre voltam para conferência, independentemente do que o modelo tenha decidido.

São garantias do sistema. Não são pedidos feitos ao modelo.`,
    scriptZh: `这里有一个步骤我必须展示，因为它正是我们与众不同之处。

在模型给出结果之后，核验结果的不是人工智能，而是软件。

一共四条既定规则。

每一项资料都对应真实的话语。每个值都附带原句、分秒与说话人，系统会在转写稿中查找该原句：若不在其中，该值即标为未经确认。凭空杜撰的引文比没有引文更糟，因为它制造了证据。

中医的诊察只认医者之言。舌象、脉象、按诊与证型，只有医者口述时才会写入；凡归于患者之口的所见，一律弃去。

沉默绝不写成记录。无人说过的内容留空，标注为未告知。

至于敏感事项，例如用药、妊娠、抗凝药、起搏器、手术与过敏，无论模型作何判定，一律回到复核。

这些是系统的保障，不是对模型提出的请求。`,
  },
  {
    key: "hypotheses",
    roteiroSlide: 16,
    block: 7,
    blockTitle: { pt: "O prontuário que escuta", zh: "会倾听的病历" },
    timeRange: "22:30–34:30",
    kicker: { pt: "Apoio ao raciocínio clínico", zh: "临床推理辅助" },
    title: { pt: "Hipóteses de padrões de desarmonia", zh: "证型假说" },
    subtitle: {
      pt: "Sinais que favorecem · sinais que contradizem · dados que faltam",
      zh: "支持的征象 · 不支持的征象 · 尚待查证",
    },
    stageNote: "Slide 16 · Hipóteses de padrões + as quatro camadas + a frase do contrato ético (ler verbatim).",
    script: `A partir dos dados organizados, o MedChina AI prepara hipóteses de padrões de desarmonia.

Para cada hipótese, apresenta os sinais que favorecem, os que contradizem e os dados que ainda faltam.

Depois que o profissional valida um padrão, o sistema pode preparar sugestões de pontos e combinações, estratégias de tonificação ou dispersão e apoio a técnicas como moxabustão, auriculoterapia, ventosaterapia e dietoterapia chinesa, com checagem de contraindicações.

Também pode preparar o plano terapêutico e os documentos para casa do paciente.

Mas a decisão final continua sendo do profissional.

O prontuário diferencia aquilo que o paciente relatou, aquilo que o profissional observou, aquilo que a inteligência artificial inferiu e aquilo que o profissional decidiu.

Essa separação é essencial.`,
    scriptZh: `在资料被整理之后，MedChina AI 会准备证型假说。

每一条假说都列出支持的征象、不支持的征象，以及尚待查证的资料。

在专业人员确认某一证型之后，系统可以准备取穴与配穴的建议、补法或泻法的思路，以及艾灸、耳穴、拔罐与中医食疗等技术的辅助意见，并附禁忌症的核查。

它也可以准备治疗方案，以及交给患者带回家的文件。

但最终的决定权始终在专业人员手中。

病历会区分：患者所述、医者所察、人工智能所推，以及医者所决。

这一区分至关重要。`,
  },
  {
    key: "testimony-user",
    block: 7,
    blockTitle: { pt: "O prontuário que escuta", zh: "会倾听的病历" },
    timeRange: "22:30–34:30",
    kicker: { pt: "Depoimento", zh: "证言" },
    title: { pt: "Como ter um colega na sala", zh: "仿佛诊室里多了一位同道" },
    subtitle: {
      pt: "Quem trabalha sozinho em consultório sabe o valor disso",
      zh: "独自执业的人，最懂这份价值",
    },
    stageNote: "Vídeo 2 · Hellen, usuária do MedChina, 60–90s, legendado.",
    script: `Nossos usuários descrevem essa experiência de um jeito que me emociona: como ter um colega na sala. Um mentor que auxilia no raciocínio, apresenta pontos de vista e faz avaliações cuidadosas que nos fazem ver mais e melhor o cenário do paciente. Quem trabalha sozinho em consultório sabe o valor disso.

Mas ninguém explica isso melhor do que quem usa. Ouçam a Hellen.`,
    scriptZh: `我们的用户描述这种体验的方式让我动容：就像诊室里多了一位同道。一位在推理上给予帮助的伙伴，提出不同的视角，做出细致的评估，让我们把患者的全貌看得更多、更清楚。独自执业的人，最懂这份价值。

不过，没有人比使用者本人讲得更好。请听 Hellen 的讲述。`,
    media: {
      kind: "testimony",
      label: { pt: "Depoimento · usuária do MedChina", zh: "证言 · MedChina 使用者" },
      duration: "60–90s",
      // Served off the site instead of from `public/`: the file is 149 MiB and
      // GitHub refuses any blob over 100 MiB, so it cannot ship in the repo.
      // A remote source is NOT probed (see `useAssetAvailable`) and needs the
      // room to have internet — if the venue does not, this slide falls back to
      // the composed standby card.
      sourceUrl: "https://medchinaprontuarios.com.br/depo-hellen.mp4",
      speaker: { pt: "Hellen", zh: "Hellen" },
      role: { pt: "Terapeuta de MTC · usuária do MedChina", zh: "中医治疗师 · MedChina 用户" },
      productionNote:
        "Vídeo legendado em mandarim, 16:9, 60–90s. Hospedado em https://medchinaprontuarios.com.br/depo-hellen.mp4 (149 MB, fora do repositório). DEPENDE DE INTERNET na sala: teste o link no wi-fi do evento antes de subir ao palco.",
    },
  },
  {
    key: "library",
    roteiroSlide: 17,
    block: 7,
    blockTitle: { pt: "O prontuário que escuta", zh: "会倾听的病历" },
    timeRange: "22:30–34:30",
    kicker: { pt: "Conteúdo e fontes", zh: "内容与来源" },
    title: { pt: "Biblioteca clínica, não a internet aberta", zh: "临床知识库，而非开放互联网" },
    subtitle: {
      pt: "Cada resposta vem com a fonte citada — e cada fonte é conferida",
      zh: "每个答案都附出处——每一处出处都经核验",
    },
    stageNote:
      "Slide 17 (1ª parte) · Biblioteca clínica. Se perguntarem “mas o modelo não foi treinado na internet inteira?”: sim, além da biblioteca o modelo carrega o conhecimento geral do próprio treinamento — é exatamente por isso que o sistema fala em correspondência com os dados registrados e não em certeza, apresenta os sinais contrários junto dos favoráveis, exige validação em tudo, e uma hipótese sem fonte de apoio diz isso explicitamente.",
    script: `Dois pontos finais sobre a plataforma.

O primeiro é a biblioteca clínica. O profissional pode estudar e tirar dúvidas conversando com uma base de conhecimento de medicina chinesa com curadoria, e cada resposta vem com as fontes citadas.

A inteligência artificial não navega na internet: ela consulta esse acervo, e cada citação é conferida contra o trecho que foi realmente entregue a ela.

E cada profissional pode adicionar os próprios protocolos, que passam a alimentar as sugestões do seu consultório.`,
    scriptZh: `关于平台，还有最后两点。

第一点是临床知识库。专业人员可以通过对话来研习与释疑，其依据是一套经过甄选的中医知识库，而且每个答案都附有出处。

人工智能并不上网检索：它查阅的是这套馆藏，并且每一处引用都要对照实际交付给它的片段加以核验。

每位专业人员也可以加入自己的方案，用于其诊所的建议生成。`,
  },
  {
    key: "consent-security",
    block: 7,
    blockTitle: { pt: "O prontuário que escuta", zh: "会倾听的病历" },
    timeRange: "22:30–34:30",
    kicker: { pt: "Segurança", zh: "数据安全" },
    title: { pt: "Dado clínico é o dado mais sensível que existe", zh: "临床数据是最敏感的数据" },
    subtitle: {
      pt: "Autorização por finalidade, e proteção que não depende de boa vontade",
      zh: "按用途授权，保护不靠自觉",
    },
    stageNote: "Slide 17 (2ª parte) · Consentimento e segurança.",
    script: `O segundo é a segurança, porque dado clínico é o dado mais sensível que existe.

O consentimento do paciente é específico e versionado: uma autorização para a gravação, outra para o processamento por inteligência artificial, e a recusa nunca impede o atendimento manual.

Tudo é criptografado, cada acesso fica em trilha de auditoria e nenhum áudio ou conteúdo clínico é usado para treinar modelos públicos de IA. Seguimos a lei brasileira de proteção de dados desde a concepção do sistema.

E uma decisão de que me orgulho: o plano gratuito do MedChina oferece o prontuário manual completo, com pacientes e registros ilimitados, para sempre. O que se paga é a automação: o tempo que a tecnologia devolve ao profissional.`,
    scriptZh: `第二点是安全，因为临床数据是最敏感的数据。

患者的知情同意是分项的，并且带有版本：录音一项授权，人工智能处理另一项授权；拒绝授权绝不妨碍以人工方式完成诊疗。

全程加密，每次访问都留有审计轨迹，任何录音或临床内容都不会用于训练公开的人工智能模型。系统自设计之初即遵循巴西的数据保护法。

还有一项让我引以为豪的决定：MedChina 的免费方案永久提供完整的手工病历，患者与记录数量不限。付费购买的是自动化——是技术为专业人员省回的时间。`,
  },
  {
    key: "four-examinations",
    roteiroSlide: 18,
    block: 8,
    blockTitle: { pt: "Tecnologia que respeita a tradição", zh: "尊重传统的技术" },
    timeRange: "34:30–37:00",
    kicker: { pt: "望 · 闻 · 问 · 切", zh: "四诊合参" },
    title: { pt: "O que a IA do MedChina não faz", zh: "MedChina 不做的事" },
    subtitle: {
      pt: "",
      zh: "",
    },
    stageNote: "Slide 18 · O que a IA não faz (望闻问切 em destaque).",
    script: `Eu sei que falar de inteligência artificial em medicina tradicional chinesa pode parecer uma contradição.

Para mim, é justamente o contrário.

A medicina chinesa é uma medicina de presença.

Vocês conhecem isso melhor do que ninguém: wàng, wén, wèn, qiè — observar, ouvir e cheirar, perguntar e palpar.

O MedChina AI não olha, não palpa e não decide.

Ele escuta, organiza, lembra e pergunta.

Ele ajuda a devolver ao profissional aquilo que a burocracia pode roubar: tempo e atenção.

Com a nova regulamentação, o registro clínico também ganha ainda mais importância.

Um prontuário bem feito protege o paciente, protege o profissional e dignifica a profissão.`,
    scriptZh: `我知道，在中医里谈人工智能，听起来可能像是自相矛盾。

对我而言，恰恰相反。

中医是一门讲究"在场"的医学。

这一点各位比谁都清楚：望、闻、问、切。

MedChina AI 不观察，不触诊，也不做决定。

它只倾听、整理、提醒与发问。

它帮助把文书所能夺走的东西还给专业人员：时间与专注。

随着新的立法，临床记录也变得更加重要。

一份做得好的病历，保护患者，保护医者，也让这门职业更有尊严。`,
  },
  {
    key: "bridge",
    roteiroSlide: 19,
    block: 9,
    blockTitle: { pt: "A ponte Brasil–China", zh: "巴西—中国之桥" },
    timeRange: "37:00–40:00",
    kicker: { pt: "Cooperação que já existe", zh: "已然存在的合作" },
    title: { pt: "Instituto Confúcio de Medicina Chinesa", zh: "中医孔子学院" },
    subtitle: {
      pt: "Goiânia · Universidade Federal de Goiás e Universidade de Medicina Chinesa de Hebei",
      zh: "戈亚尼亚 · 戈亚斯联邦大学与河北中医药大学",
    },
    stageNote: "Slide 19 · Instituto Confúcio de Medicina Chinesa — Goiânia.",
    script: `Quero terminar falando de uma ponte entre nossos dois países.

Desde 2019, Goiânia sedia o Instituto Confúcio de Medicina Chinesa, uma parceria entre a Universidade Federal de Goiás e a Universidade de Medicina Chinesa de Hebei.

Essa cooperação aproxima nossos dois países.

O Brasil tem centenas de milhares de profissionais interessados em conhecimento de qualidade.

A China tem fontes, mestres e uma experiência clínica acumulada por milênios.

Entre os dois países, podemos construir ainda mais pontes.

Nós queremos ser uma delas.

Universidades, professores e instituições chinesas que desejem alcançar o público brasileiro podem encontrar no MedChina AI um canal direto com essa comunidade — por meio de eventos, cursos e conteúdo de referência, com a devida curadoria e licença, dentro da biblioteca clínica.

A medicina chinesa cresceu no Brasil por dois séculos sem falar português.

Imaginem o que ela pode fazer agora que aprendeu.`,
    scriptZh: `最后，我想谈一座连接我们两国的桥。

自 2019 年起，戈亚尼亚设有中医孔子学院，由戈亚斯联邦大学与河北中医药大学共建。

这项合作拉近了我们两个国家。

巴西有数十万渴求优质知识的专业人员。

中国有典籍、有名师，也有数千年积累的临床经验。

在两国之间，我们还可以建起更多的桥。

我们希望成为其中的一座。

希望触达巴西受众的中国高校、教师与机构，可以在 MedChina AI 中找到直通这一群体的通道——通过活动、课程，以及在恰当的甄选与授权之下纳入临床知识库的权威内容。

两个世纪以来，中医在巴西生长，却从未说过葡萄牙语。

请想象，如今它学会了，能走到多远。`,
  },
  {
    key: "closing",
    roteiroSlide: 20,
    block: 9,
    blockTitle: { pt: "Encerramento", zh: "闭幕" },
    timeRange: "37:00–40:00",
    kicker: { pt: "Do papel ao prontuário inteligente", zh: "从纸质病历到智能病历" },
    title: { pt: "Obrigada · 谢谢", zh: "谢谢 · Obrigada" },
    subtitle: {
      pt: "Honrando os ancestrais que escreveram cada ideograma",
      zh: "以敬那些写下每一个汉字的先贤",
    },
    stageNote: "Slide 20 · Encerramento — logo MedChina + agradecimento + QR. Abrir para perguntas, se houver tempo.",
    script: `Termino com uma imagem simples.

Um prontuário que escuta, organiza e prepara, para que o terapeuta brasileiro possa fazer aquilo que os mestres desta terra fazem há milênios: olhar para o paciente.

Nossa caminhada ainda é longa.

Mas queremos continuar expandindo, divulgando, ensinando e praticando a medicina chinesa no Brasil, sempre com respeito aos ancestrais que construíram essa sabedoria.

Que a tecnologia nos ajude a preservar aquilo que é essencialmente humano na nossa profissão.

Muito obrigada. 谢谢 — Xièxie.`,
    scriptZh: `我以一个朴素的画面作结。

一份会倾听、会整理、会预备的病历，好让巴西的治疗师能做这片土地上的先师们做了数千年的事：看着患者。

我们要走的路还很长。

但我们希望继续在巴西扩展、传播、教授并实践中医，始终敬重创造了这门智慧的先贤。

愿技术帮助我们守住这门职业中最本质的、属于人的部分。

非常感谢。谢谢。`,
  },

  /*
    Everything below is the annex: four slides answering the congress
    organisation's four written questions, in full. They are outside the forty
    minutes (`annex` keeps them out of the counter and the progress bar) and
    exist to be jumped to during the questions.
  */
  {
    key: "annex-stages",
    annex: true,
    block: 10,
    blockTitle: { pt: "Anexo · perguntas da organização", zh: "附录 · 主办方提问" },
    timeRange: "Depois da palestra",
    kicker: { pt: "Pergunta 1", zh: "问题一" },
    title: { pt: "Como a IA analisa os dados da consulta", zh: "AI 如何分析诊疗数据" },
    subtitle: {
      pt: "Quatro etapas, nesta ordem. As três primeiras são automáticas; a quarta só acontece quando a profissional pede.",
      zh: "四个步骤，依此顺序。前三步自动进行；第四步仅在医者请求时才发生。",
    },
    stageNote: "Anexo 1 · resposta completa à pergunta 1. Não faz parte dos quarenta minutos.",
    script: `Resposta completa à primeira pergunta da organização: o processamento acontece em quatro etapas, nesta ordem.

As três primeiras são automáticas. A quarta só acontece quando a profissional pede, e apenas nos planos que incluem o recurso.`,
    scriptZh: `对主办方第一个问题的完整回答：处理分四个步骤，依此顺序进行。

前三步自动完成。第四步仅在专业人员请求时才发生，且仅限包含该功能的订阅方案。`,
  },
  {
    key: "annex-scope",
    annex: true,
    block: 10,
    blockTitle: { pt: "Anexo · perguntas da organização", zh: "附录 · 主办方提问" },
    timeRange: "Depois da palestra",
    kicker: { pt: "Pergunta 2", zh: "问题二" },
    title: { pt: "Qual conteúdo da consulta entra na análise", zh: "哪些诊疗内容进入分析" },
    subtitle: {
      pt: "Depende da etapa, e cada uma enxerga apenas o necessário",
      zh: "视步骤而定，每一步只看其所需",
    },
    stageNote:
      "Anexo 2 · resposta completa à pergunta 2. O ponto que mais costuma ser perguntado é o isolamento entre consultórios, no rodapé.",
    script: `Resposta completa à segunda pergunta: depende da etapa, e cada uma enxerga apenas o necessário.

E, em nenhuma delas, a inteligência artificial acessa dados de outros pacientes ou de outros profissionais.`,
    scriptZh: `对第二个问题的完整回答：视步骤而定，每一步只看其所需。

而且在任何一步，人工智能都不会访问其他患者或其他专业人员的资料。`,
  },
  {
    key: "annex-returns",
    annex: true,
    block: 10,
    blockTitle: { pt: "Anexo · perguntas da organização", zh: "附录 · 主办方提问" },
    timeRange: "Depois da palestra",
    kicker: { pt: "Pergunta 3", zh: "问题三" },
    title: { pt: "O que exatamente a IA devolve", zh: "AI 究竟返回什么" },
    subtitle: {
      pt: "Cada campo chega com a origem, o estado e a procedência — a frase, o minuto, quem falou e se foi confirmada na transcrição",
      zh: "每一字段都附带来源、状态与出处——原句、分秒、说话人，以及是否已在转写中得到确认",
    },
    stageNote: "Anexo 3 · resposta completa à pergunta 3.",
    script: `Resposta completa à terceira pergunta: o que a análise devolve.

Tudo isso é rascunho. Nada entra no prontuário como fato até a profissional revisar.`,
    scriptZh: `对第三个问题的完整回答：分析返回什么。

凡此皆为草稿。未经专业人员复核，任何内容都不会作为事实进入病历。`,
  },
  {
    key: "annex-corpus",
    annex: true,
    block: 10,
    blockTitle: { pt: "Anexo · perguntas da organização", zh: "附录 · 主办方提问" },
    timeRange: "Depois da palestra",
    kicker: { pt: "Pergunta 4", zh: "问题四" },
    title: { pt: "De onde vem o conhecimento", zh: "知识从何而来" },
    subtitle: {
      pt: "De uma biblioteca clínica curada dentro da plataforma — não da internet aberta",
      zh: "来自平台内部经甄选的临床知识库——而非开放互联网",
    },
    stageNote:
      "Anexo 4 · resposta completa à pergunta 4. A nota de honestidade no rodapé é a resposta pronta para “mas o modelo não foi treinado na internet inteira?”.",
    script: `Resposta completa à quarta pergunta: de onde vem o conteúdo.

A biblioteca é curada e vive dentro da plataforma. A inteligência artificial não navega na internet.

E há uma observação de honestidade que fazemos questão de registrar: além da biblioteca, o modelo carrega o conhecimento geral do próprio treinamento. É exatamente por isso que tudo aqui é apresentado como correspondência, com os sinais contrários à vista, e exigindo validação profissional.`,
    scriptZh: `对第四个问题的完整回答：内容从何而来。

知识库经过甄选，且存在于平台内部。人工智能不上网检索。

还有一点出于诚实，我们坚持载明：除知识库之外，模型还携带其自身训练所得的一般知识。正因如此，这里的一切都以"对应度"呈现，把不支持的征象一并列出，并且要求专业人员验证。`,
  },
];
