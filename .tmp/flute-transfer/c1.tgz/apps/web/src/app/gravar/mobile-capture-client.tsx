"use client";

import { useTranslations } from "next-intl";
import { useCallback, useEffect, useRef, useState } from "react";

import { Alert, Box, Button, Card, CardContent, CircularProgress, LinearProgress, Typography } from "@mui/material";

import NiCamera from "@/icons/nexture/ni-camera";
import NiCheckSquare from "@/icons/nexture/ni-check-square";
import NiDocumentFull from "@/icons/nexture/ni-document-full";
import NiMicrophone from "@/icons/nexture/ni-microphone";
import NiPause from "@/icons/nexture/ni-pause";
import NiSquare from "@/icons/nexture/ni-square";
import { isCaptureLinkToken } from "@/lib/capture-link-token";
import {
  appendCaptureChunk,
  beginCaptureStore,
  clearCapture,
  recoverCapture,
  requestPersistentStorage,
} from "@/lib/mobile-capture-store";
import { cn } from "@/lib/utils";

type Phase =
  | "loading"
  | "invalid"
  | "network"
  | "blocked"
  | "idle"
  | "recovered"
  | "recording"
  | "paused"
  | "uploading"
  | "done"
  | "error";
type Resolved = {
  patientFirstName: string | null;
  consultationEditable: boolean;
  audioConsent: boolean;
  /** Audio can actually be captured now (consent + minutes). Photos do not
   *  depend on this — a free workspace attaches photos without AI. */
  audioAvailable: boolean;
  imagesConsent: boolean;
  mode: "ai" | "audio_only";
  recordingStatus: string | null;
};

/**
 * A file this phone has already delivered. `previewUrl` is an object URL over
 * the LOCAL File — the upload target is a private bucket and this page is
 * token-authorized with no login, so reading the image back would mean opening
 * a download path that does not need to exist. The blob never leaves the
 * device; it is revoked on unmount.
 */
type SentAttachment = { id: string; name: string; isImage: boolean; previewUrl: string | null };

/** Rolling waveform window: 28 bars sampled every 110ms ≈ the last 3 seconds. */
const WAVEFORM_BARS = 28;
const WAVEFORM_SAMPLE_MS = 110;

const MAX_DURATION_SECONDS = 120 * 60;
const BUCKET = "transcriptions";
// Speech needs little: 32 kbps mono opus keeps an hour near ~14 MB, which
// protects the upload on clinic wifi AND the transcription provider limits.
const AUDIO_BITS_PER_SECOND = 32_000;
const SILENCE_WARNING_MS = 60_000;

const bestMime = () => {
  const candidates = ["audio/webm;codecs=opus", "audio/webm", "audio/mp4"];
  return candidates.find((mime) => typeof MediaRecorder !== "undefined" && MediaRecorder.isTypeSupported(mime)) ?? "";
};

/** sessionStorage key for the clientUploadId, scoped to this link's token. */
const uploadIdKey = (token: string) => `medchina-capture-upload:${token.slice(0, 16)}`;

/**
 * The same URL `uploadToSignedUrl` builds, assembled here from the browser's
 * own public Supabase URL — the phone must reach the storage host it knows,
 * not whatever origin the server resolved.
 */
const signedUploadUrl = (path: string, uploadToken: string, bucket: string = BUCKET) =>
  `${process.env.NEXT_PUBLIC_SUPABASE_URL}/storage/v1/object/upload/sign/${bucket}/${path}?token=${encodeURIComponent(uploadToken)}`;

const ATTACHMENTS_BUCKET = "clinical-attachments";

/**
 * Upload to the signed URL with REAL progress events — fetch reports none, and
 * a determinate bar frozen at 0% for minutes reads as "stuck" on clinic wifi.
 * The request mirrors what `uploadToSignedUrl` sends for a Blob (PUT +
 * multipart with cacheControl), so this only adds progress, not a new
 * server contract.
 */
function putWithProgress(url: string, blob: Blob, onProgress: (ratio: number) => void): Promise<void> {
  return new Promise((resolve, reject) => {
    const form = new FormData();
    form.append("cacheControl", "3600");
    form.append("", blob);

    const xhr = new XMLHttpRequest();
    xhr.open("PUT", url);
    // The signed token already authorizes overwriting, which is what makes a
    // resumed upload after a failed attempt land on the same object.
    xhr.setRequestHeader("x-upsert", "true");
    xhr.upload.onprogress = (event) => {
      if (event.lengthComputable && event.total > 0) onProgress(event.loaded / event.total);
    };
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) resolve();
      else reject(new Error("storage_upload_failed"));
    };
    xhr.onerror = () => reject(new Error("storage_upload_failed"));
    xhr.ontimeout = () => reject(new Error("storage_upload_failed"));
    xhr.send(form);
  });
}

/**
 * Audio capture over a QR bearer token — no login, no app. Mirrors the
 * essentials of the desktop recorder (mic before server state, wall-clock
 * timer, level meter as honest proof, server-confirmed upload) and adds the
 * durability a phone needs: chunks persisted to IndexedDB as they arrive
 * (reload/crash never loses the audio), a screen wake lock while recording,
 * suspension detection when the OS freezes the tab, and real upload progress.
 * With an 'ai'-mode link the delivered audio enters the clinical pipeline —
 * the phone on the table is the microphone of the automatic anamnesis.
 */
export default function MobileCaptureClient() {
  const t = useTranslations("product");
  const [phase, setPhase] = useState<Phase>("loading");
  const [resolved, setResolved] = useState<Resolved | null>(null);
  const [errorKey, setErrorKey] = useState<string | null>(null);
  const [warningKey, setWarningKey] = useState<string | null>(null);
  const [seconds, setSeconds] = useState(0);
  const [level, setLevel] = useState(0);
  const [levels, setLevels] = useState<number[]>([]);
  const [uploadProgress, setUploadProgress] = useState(0);
  // Photos/documents share the SAME QR session as the audio — the phone is
  // camera and microphone in one flow.
  const [attaching, setAttaching] = useState(false);
  const [attachments, setAttachments] = useState<SentAttachment[]>([]);
  const [attachError, setAttachError] = useState<string | null>(null);

  const token = useRef<string | null>(null);
  const attachmentsRef = useRef<SentAttachment[]>([]);
  const photoInput = useRef<HTMLInputElement>(null);
  const fileInput = useRef<HTMLInputElement>(null);
  const clientUploadId = useRef<string | null>(null);
  const mediaRecorder = useRef<MediaRecorder | null>(null);
  const chunks = useRef<Blob[]>([]);
  const stream = useRef<MediaStream | null>(null);
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);
  const heartbeat = useRef<ReturnType<typeof setInterval> | null>(null);
  const startedAtRef = useRef(0);
  const pausedTotalRef = useRef(0);
  const pausedAtRef = useRef(0);
  const secondsRef = useRef(0);
  const lastSoundAtRef = useRef(0);
  const audioContextRef = useRef<AudioContext | null>(null);
  const levelFrameRef = useRef<number | null>(null);
  const lastBarAtRef = useRef(0);
  const wakeLockRef = useRef<WakeLockSentinel | null>(null);
  const pendingBlob = useRef<{ blob: Blob; duration: number; mime: string } | null>(null);
  const phaseRef = useRef<Phase>("loading");
  phaseRef.current = phase;
  attachmentsRef.current = attachments;

  // Object URLs are a manual allocation: without this the previews would hold
  // every full-resolution photo of the session alive on a phone.
  useEffect(
    () => () => {
      for (const attachment of attachmentsRef.current) {
        if (attachment.previewUrl) URL.revokeObjectURL(attachment.previewUrl);
      }
    },
    [],
  );

  const call = useCallback(async (path: string, payload: Record<string, unknown>) => {
    const response = await fetch(`/api/public/capture/${path}`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ token: token.current, ...payload }),
    });
    const body = (await response.json().catch(() => ({}))) as { ok?: boolean; code?: string; [k: string]: unknown };
    return { ok: response.ok && body.ok === true, status: response.status, body };
  }, []);

  // Reserve → upload to a signed URL → confirm, once per file. Gated server-side
  // (a photo needs clinical-images consent); a refusal is stated, never a crash.
  const sendAttachments = useCallback(
    async (files: FileList | null) => {
      if (!files || files.length === 0) return;
      setAttaching(true);
      setAttachError(null);
      for (const file of Array.from(files)) {
        try {
          const reserve = await call("attachment", { mime: file.type });
          if (!reserve.ok || typeof reserve.body.path !== "string" || typeof reserve.body.token !== "string") {
            setAttachError(
              reserve.body.code === "images_consent_required" ? "capture-photo-consent" : "capture-photo-error",
            );
            continue;
          }
          const path = reserve.body.path as string;
          await putWithProgress(
            signedUploadUrl(path, reserve.body.token as string, ATTACHMENTS_BUCKET),
            file,
            () => undefined,
          );
          const confirmed = await call("attachment/confirm", {
            attachmentId: reserve.body.attachmentId,
            path,
            size: file.size,
          });
          if (confirmed.ok) {
            const isImage = file.type.startsWith("image/");
            setAttachments((current) => [
              ...current,
              {
                id: `${Date.now()}-${current.length}-${file.name}`,
                name: file.name,
                isImage,
                previewUrl: isImage ? URL.createObjectURL(file) : null,
              },
            ]);
          } else setAttachError("capture-photo-error");
        } catch {
          setAttachError("capture-photo-error");
        }
      }
      if (photoInput.current) photoInput.current.value = "";
      if (fileInput.current) fileInput.current.value = "";
      setAttaching(false);
    },
    [call],
  );

  const resolve = useCallback(async () => {
    const raw = window.location.hash.replace(/^#/, "");
    if (!isCaptureLinkToken(raw)) {
      setPhase("invalid");
      return;
    }
    token.current = raw;
    let result: Awaited<ReturnType<typeof call>>;
    try {
      result = await call("resolve", {});
    } catch {
      // Clinic wifi drops: distinguish "no connection" from "dead link" so a
      // retry is offered instead of a dead end.
      setPhase("network");
      return;
    }
    if (!result.ok) {
      setPhase("invalid");
      return;
    }
    const body = result.body;
    const context: Resolved = {
      patientFirstName: (body.patientFirstName as string | null) ?? null,
      consultationEditable: body.consultationEditable === true,
      audioConsent: body.audioConsent === true,
      audioAvailable: body.audioAvailable === true,
      imagesConsent: body.imagesConsent === true,
      mode: body.mode === "ai" ? "ai" : "audio_only",
      recordingStatus: (body.recordingStatus as string | null) ?? null,
    };
    setResolved(context);
    // Only a closed consultation blocks the whole page. Missing audio consent
    // no longer does — photos and documents remain available (that is the free
    // workspace's path). Audio simply hides itself below.
    if (!context.consultationEditable) {
      setPhase("blocked");
      return;
    }

    // A crashed/reloaded page may hold unsent audio for this link's
    // consultation — offer it back before anything else. The recording row is
    // idempotent on clientUploadId, so even a FRESH QR for the same
    // consultation can deliver it.
    const storedUploadId = window.sessionStorage.getItem(uploadIdKey(raw));
    if (storedUploadId) {
      const recovered = await recoverCapture(storedUploadId);
      if (recovered) {
        clientUploadId.current = storedUploadId;
        setPhase("recovered");
        return;
      }
    }

    // A capture already delivered on this consultation shows as done rather
    // than inviting a second one.
    if (context.recordingStatus === "ready" || context.recordingStatus === "uploaded") setPhase("done");
    else setPhase("idle");
  }, [call]);

  useEffect(() => {
    void resolve();
  }, [resolve]);

  const stopTimers = () => {
    if (timer.current) clearInterval(timer.current);
    if (heartbeat.current) clearInterval(heartbeat.current);
    timer.current = null;
    heartbeat.current = null;
  };
  const stopLevelMeter = useCallback(() => {
    if (levelFrameRef.current !== null) cancelAnimationFrame(levelFrameRef.current);
    levelFrameRef.current = null;
    void audioContextRef.current?.close().catch(() => undefined);
    audioContextRef.current = null;
    setLevel(0);
    setLevels([]);
  }, []);
  const releaseStream = useCallback(() => {
    stream.current?.getTracks().forEach((track) => track.stop());
    stream.current = null;
  }, []);
  const releaseWakeLock = useCallback(() => {
    void wakeLockRef.current?.release().catch(() => undefined);
    wakeLockRef.current = null;
  }, []);
  const requestWakeLock = useCallback(async () => {
    try {
      if ("wakeLock" in navigator) {
        wakeLockRef.current = await navigator.wakeLock.request("screen");
      }
    } catch {
      // Denied or unsupported — the on-screen "keep this open" hint covers it.
    }
  }, []);

  useEffect(
    () => () => {
      stopTimers();
      stopLevelMeter();
      releaseStream();
      releaseWakeLock();
    },
    [releaseStream, releaseWakeLock, stopLevelMeter],
  );

  // The OS releases the wake lock (and iOS may suspend the recorder) whenever
  // the tab hides. On return: re-arm the lock and detect a silent gap — a
  // recorder that died while hidden must surface, never pretend to record.
  useEffect(() => {
    const onVisibility = () => {
      if (document.visibilityState !== "visible") return;
      if (phaseRef.current === "recording") {
        void requestWakeLock();
        if (mediaRecorder.current && mediaRecorder.current.state === "inactive") {
          setWarningKey("capture-mobile-gap-warning");
        }
      }
    };
    document.addEventListener("visibilitychange", onVisibility);
    return () => document.removeEventListener("visibilitychange", onVisibility);
  }, [requestWakeLock]);

  const startLevelMeter = useCallback((media: MediaStream) => {
    const Ctor =
      window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return;
    try {
      const context = new Ctor();
      audioContextRef.current = context;
      const analyser = context.createAnalyser();
      analyser.fftSize = 1024;
      context.createMediaStreamSource(media).connect(analyser);
      const buffer = new Uint8Array(analyser.frequencyBinCount);
      const tick = () => {
        analyser.getByteTimeDomainData(buffer);
        let peak = 0;
        for (const sample of buffer) peak = Math.max(peak, Math.abs(sample - 128));
        const value = Math.min(1, peak / 96);
        if (value > 0.04) lastSoundAtRef.current = Date.now();
        setLevel(value);
        // The waveform is a rolling window of REAL peaks, sampled well below
        // frame rate: it is the level meter of invariant (6) with memory, so a
        // silent stretch stays visible as flat bars instead of scrolling away
        // in the same instant. Never a canned animation — that would draw
        // "sound is arriving" over a dead microphone.
        const now = performance.now();
        if (now - lastBarAtRef.current >= WAVEFORM_SAMPLE_MS) {
          lastBarAtRef.current = now;
          setLevels((previous) =>
            previous.length < WAVEFORM_BARS ? [...previous, value] : [...previous.slice(1), value],
          );
        }
        levelFrameRef.current = requestAnimationFrame(tick);
      };
      levelFrameRef.current = requestAnimationFrame(tick);
    } catch {
      audioContextRef.current = null;
    }
  }, []);

  const upload = useCallback(
    async (blob: Blob, duration: number, mime: string) => {
      pendingBlob.current = { blob, duration, mime };
      setPhase("uploading");
      setUploadProgress(0);
      setErrorKey(null);
      try {
        const durationSeconds = blob.size > 0 ? Math.max(1, duration) : duration;
        const local = await call("state", { action: "local", durationSeconds, sizeBytes: blob.size, mime });
        if (!local.ok) throw new Error(String(local.body.code ?? "state_failed"));
        const urlResult = await call("upload-url", { mime });
        if (!urlResult.ok || typeof urlResult.body.path !== "string" || typeof urlResult.body.token !== "string") {
          throw new Error(String(urlResult.body.code ?? "upload_unavailable"));
        }
        const path = urlResult.body.path as string;
        await call("state", { action: "uploading" });

        await putWithProgress(signedUploadUrl(path, urlResult.body.token as string), blob, setUploadProgress);
        setUploadProgress(1);

        const confirmed = await call("state", { action: "uploaded", audioPath: path });
        if (!confirmed.ok) throw new Error(String(confirmed.body.code ?? "state_failed"));
        pendingBlob.current = null;
        if (clientUploadId.current) void clearCapture(clientUploadId.current);
        if (token.current) window.sessionStorage.removeItem(uploadIdKey(token.current));
        setWarningKey(null);
        setPhase("done");
      } catch (error) {
        const code = error instanceof Error ? error.message : "";
        setErrorKey(code === "capture_link_invalid" ? "capture-mobile-link-lost" : "capture-mobile-upload-error");
        setPhase("error");
      }
    },
    [call],
  );

  const sendRecovered = useCallback(async () => {
    const uploadId = clientUploadId.current;
    if (!uploadId) return;
    const recovered = await recoverCapture(uploadId);
    if (!recovered) {
      setPhase("idle");
      return;
    }
    setErrorKey(null);
    // Idempotent: replays into the SAME recording row when it already exists.
    try {
      const begun = await call("begin", { clientUploadId: uploadId });
      if (!begun.ok) {
        setErrorKey(begun.body.code === "recording_already_open" ? "capture-mobile-open" : "capture-mobile-error");
        setPhase("error");
        return;
      }
    } catch {
      setErrorKey("capture-mobile-network-error");
      setPhase("error");
      return;
    }
    void upload(recovered.blob, recovered.approxSeconds, recovered.mime);
  }, [call, upload]);

  const start = async () => {
    setErrorKey(null);
    setWarningKey(null);
    let media: MediaStream;
    try {
      media = await navigator.mediaDevices.getUserMedia({
        audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true },
      });
    } catch {
      setErrorKey("capture-mobile-mic-denied");
      setPhase("error");
      return;
    }

    const uploadId = clientUploadId.current ?? crypto.randomUUID();
    clientUploadId.current = uploadId;
    let begun: Awaited<ReturnType<typeof call>>;
    try {
      begun = await call("begin", { clientUploadId: uploadId });
    } catch {
      // Network died AFTER the mic opened — release it, or the light stays on
      // with the UI stuck in idle.
      media.getTracks().forEach((track) => track.stop());
      setErrorKey("capture-mobile-network-error");
      setPhase("error");
      return;
    }
    if (!begun.ok) {
      media.getTracks().forEach((track) => track.stop());
      setErrorKey(begun.body.code === "recording_already_open" ? "capture-mobile-open" : "capture-mobile-error");
      setPhase("error");
      return;
    }

    try {
      if (token.current) window.sessionStorage.setItem(uploadIdKey(token.current), uploadId);
      void requestPersistentStorage();
      stream.current = media;
      chunks.current = [];
      const mime = bestMime();
      const options: MediaRecorderOptions = { audioBitsPerSecond: AUDIO_BITS_PER_SECOND };
      if (mime) options.mimeType = mime;
      const recorder = new MediaRecorder(media, options);
      const effectiveMime = recorder.mimeType || mime || "audio/webm";
      void beginCaptureStore(uploadId, effectiveMime);
      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunks.current.push(event.data);
          // Durable as it arrives: a killed tab loses at most one second.
          void appendCaptureChunk(uploadId, event.data);
        }
      };
      recorder.onstop = () => {
        stopLevelMeter();
        releaseStream();
        releaseWakeLock();
        void upload(new Blob(chunks.current, { type: effectiveMime }), secondsRef.current, effectiveMime);
      };
      media.getAudioTracks().forEach((track) => {
        track.onended = () => {
          // Device lost (call came in, bluetooth dropped, OS revoked the mic):
          // deliver what exists instead of recording silence forever.
          if (mediaRecorder.current && mediaRecorder.current.state !== "inactive") {
            setWarningKey("capture-mobile-device-lost");
            stopTimers();
            mediaRecorder.current.stop();
          }
        };
      });
      mediaRecorder.current = recorder;
      recorder.start(1000);
      startedAtRef.current = Date.now();
      pausedTotalRef.current = 0;
      pausedAtRef.current = 0;
      lastSoundAtRef.current = Date.now();
      secondsRef.current = 0;
      setSeconds(0);
      setPhase("recording");
      startLevelMeter(media);
      void requestWakeLock();
      timer.current = setInterval(() => {
        const elapsed = Math.floor((Date.now() - startedAtRef.current - pausedTotalRef.current) / 1000);
        secondsRef.current = elapsed;
        setSeconds(elapsed);
        if (
          lastSoundAtRef.current > 0 &&
          Date.now() - lastSoundAtRef.current > SILENCE_WARNING_MS &&
          phaseRef.current === "recording"
        ) {
          setWarningKey("capture-mobile-silence-warning");
        }
        if (elapsed >= MAX_DURATION_SECONDS && mediaRecorder.current?.state !== "inactive") {
          stopTimers();
          mediaRecorder.current?.stop();
        }
      }, 1000);
      // Keep the 15-min token alive across a long consultation. A dead link is
      // NOT fatal (the audio is persisted locally) but the professional should
      // know a fresh QR will be needed to deliver.
      heartbeat.current = setInterval(
        () => {
          void call("state", { action: "heartbeat" })
            .then((result) => {
              if (!result.ok && result.status === 410) setWarningKey("capture-mobile-link-lost");
            })
            .catch(() => undefined);
        },
        5 * 60 * 1000,
      );
    } catch {
      releaseStream();
      releaseWakeLock();
      void call("state", { action: "cancel", errorCode: "microphone_unavailable" }).catch(() => undefined);
      setErrorKey("capture-mobile-mic-denied");
      setPhase("error");
    }
  };

  const pause = () => {
    mediaRecorder.current?.pause();
    if (timer.current) clearInterval(timer.current);
    timer.current = null;
    pausedAtRef.current = Date.now();
    setPhase("paused");
  };
  const resume = () => {
    mediaRecorder.current?.resume();
    if (pausedAtRef.current) pausedTotalRef.current += Date.now() - pausedAtRef.current;
    pausedAtRef.current = 0;
    lastSoundAtRef.current = Date.now();
    timer.current = setInterval(() => {
      const elapsed = Math.floor((Date.now() - startedAtRef.current - pausedTotalRef.current) / 1000);
      secondsRef.current = elapsed;
      setSeconds(elapsed);
    }, 1000);
    setPhase("recording");
  };
  const finish = () => {
    stopTimers();
    mediaRecorder.current?.stop();
  };
  const retryUpload = () => {
    const pending = pendingBlob.current;
    if (pending) void upload(pending.blob, pending.duration, pending.mime);
    else setPhase("idle");
  };
  const recordAnother = () => {
    // A consultation captured in parts: new idempotency key, same link.
    clientUploadId.current = null;
    if (token.current) window.sessionStorage.removeItem(uploadIdKey(token.current));
    setWarningKey(null);
    setErrorKey(null);
    void start();
  };

  const mmss = `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;

  if (phase === "loading") {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-10!">
          <CircularProgress aria-label={t("loading")} />
        </CardContent>
      </Card>
    );
  }

  if (phase === "network") {
    return (
      <Card>
        <CardContent className="flex flex-col gap-3 py-7!">
          <Typography variant="h5" component="h1">
            {t("capture-mobile-network-title")}
          </Typography>
          <Typography variant="body2" className="text-text-secondary leading-6">
            {t("capture-mobile-network-error")}
          </Typography>
          <Button variant="contained" color="primary" onClick={() => void resolve()}>
            {t("retry")}
          </Button>
        </CardContent>
      </Card>
    );
  }

  if (phase === "invalid") {
    return (
      <Card>
        <CardContent className="flex flex-col gap-2 py-7!">
          <Typography variant="h5" component="h1">
            {t("capture-mobile-invalid-title")}
          </Typography>
          <Typography variant="body2" className="text-text-secondary leading-6">
            {t("capture-mobile-invalid-body")}
          </Typography>
        </CardContent>
      </Card>
    );
  }

  if (phase === "blocked") {
    return (
      <Card>
        <CardContent className="flex flex-col gap-2 py-7!">
          <Typography variant="h5" component="h1">
            {t("capture-mobile-blocked-title")}
          </Typography>
          <Typography variant="body2" className="text-text-secondary leading-6">
            {/* The only remaining hard block is a closed consultation. */}
            {t("capture-mobile-not-editable")}
          </Typography>
        </CardContent>
      </Card>
    );
  }

  const aiMode = resolved?.mode === "ai";

  return (
    <Card>
      <CardContent className="flex flex-col gap-4 py-6!">
        <Box className="flex flex-col gap-1">
          <Typography variant="h5" component="h1" className="mb-0">
            {t("capture-mobile-title")}
          </Typography>
          <Typography variant="body2" className="text-text-secondary leading-6">
            {resolved?.patientFirstName
              ? t("capture-mobile-subtitle-named", { name: resolved.patientFirstName })
              : t("capture-mobile-subtitle")}
          </Typography>
          {aiMode && phase !== "done" && (
            <Typography variant="body2" className="text-text-secondary text-xs leading-5">
              {t("capture-mobile-ai-hint")}
            </Typography>
          )}
        </Box>

        {phase === "done" ? (
          <>
            <Alert severity="success" icon={<NiCheckSquare />}>
              {aiMode ? t("capture-mobile-done-ai") : t("capture-mobile-done")}
            </Alert>
            <Typography variant="body2" className="text-text-secondary text-xs leading-5">
              {t("capture-mobile-done-hint")}
            </Typography>
            {!aiMode && (
              <Button
                variant="outlined"
                color="primary"
                size="large"
                fullWidth
                startIcon={<NiMicrophone size="tiny" />}
                onClick={recordAnother}
              >
                {t("capture-mobile-another")}
              </Button>
            )}
          </>
        ) : phase === "recovered" ? (
          <>
            <Alert severity="info">{t("capture-mobile-recovered")}</Alert>
            <Button variant="contained" color="primary" size="large" fullWidth onClick={() => void sendRecovered()}>
              {t("capture-mobile-resume")}
            </Button>
            <Button
              variant="outlined"
              color="grey"
              size="large"
              fullWidth
              onClick={() => {
                const uploadId = clientUploadId.current;
                if (uploadId) void clearCapture(uploadId);
                if (token.current) window.sessionStorage.removeItem(uploadIdKey(token.current));
                clientUploadId.current = null;
                setPhase("idle");
              }}
            >
              {t("capture-mobile-discard-recovered")}
            </Button>
          </>
        ) : (
          <>
            {(phase === "recording" || phase === "paused") && (
              <Box className="flex flex-col items-center gap-4" role="status" aria-live="polite">
                {/* What is being captured and what will be done with it — the
                    two facts that justify a microphone being open in a room
                    with a patient, stated where she can point at them. */}
                <Box className="border-grey-100 flex w-full flex-row items-center gap-2 rounded-2xl border px-3 py-2">
                  <NiMicrophone size="tiny" className="text-primary flex-none" aria-hidden />
                  <Box className="min-w-0">
                    <Typography variant="body2" className="text-text-primary text-xs leading-4 font-semibold">
                      {t("capture-mobile-consent-badge")}
                    </Typography>
                    <Typography variant="body2" className="text-text-secondary text-xs leading-4">
                      {resolved?.mode === "ai" ? t("capture-mode-ai") : t("capture-mode-audio")}
                    </Typography>
                  </Box>
                </Box>

                {/* The disc breathes with the MEASURED level, so it is a second
                    reading of the same truth as the bars, never decoration
                    that would keep moving over a dead microphone. */}
                <Box className="relative flex h-36 w-36 flex-none items-center justify-center">
                  <span
                    aria-hidden
                    className={cn(
                      "absolute inset-0 rounded-full",
                      phase === "recording" ? "bg-primary/10" : "bg-grey-100",
                    )}
                  />
                  <span
                    aria-hidden
                    className={cn(
                      "absolute rounded-full transition-transform duration-100",
                      phase === "recording" ? "bg-primary" : "bg-grey-400",
                    )}
                    style={{
                      height: "5rem",
                      width: "5rem",
                      transform: `scale(${phase === "recording" ? 1 + Math.min(0.28, level * 0.45) : 1})`,
                    }}
                  />
                </Box>

                <Box className="flex flex-col items-center gap-1">
                  <Typography
                    variant="body2"
                    className="text-text-secondary text-center text-[0.6875rem] leading-4 font-semibold tracking-wider uppercase"
                  >
                    {phase === "recording" ? t("recorder-recording") : t("recorder-paused")}
                  </Typography>
                  <Typography variant="h2" component="p" className="text-text-primary mb-0 font-mono tabular-nums">
                    {mmss}
                  </Typography>
                </Box>

                {/* Same honest meter as before, now with ~3s of memory. The
                    scalar level stays the accessible value; the bars are the
                    visual. */}
                <Box
                  className="flex h-10 w-full flex-row items-end justify-center gap-[3px]"
                  role="meter"
                  aria-label={t("recorder-level-label")}
                  aria-valuemin={0}
                  aria-valuemax={100}
                  aria-valuenow={Math.round(level * 100)}
                >
                  {Array.from({ length: WAVEFORM_BARS }, (_, index) => {
                    // Right-aligned: the newest sample sits at the end, and an
                    // unfilled window reads as "just started", not as silence.
                    const offset = WAVEFORM_BARS - levels.length;
                    const sample = index >= offset ? levels[index - offset] : 0;
                    return (
                      <span
                        key={index}
                        aria-hidden
                        className={cn(
                          "w-[3px] flex-none rounded-full",
                          phase === "recording" ? "bg-primary" : "bg-grey-300",
                        )}
                        style={{ height: `${Math.max(10, Math.round(sample * 100))}%` }}
                      />
                    );
                  })}
                </Box>

                {phase === "recording" && (
                  <Typography variant="body2" className="text-text-secondary text-center text-xs leading-5">
                    {t("capture-mobile-screen-hint")}
                  </Typography>
                )}
              </Box>
            )}

            {phase === "uploading" && (
              <Box className="flex flex-col gap-2" role="status" aria-live="polite">
                <Typography variant="body2" className="text-text-secondary">
                  {t("recorder-uploading")}
                </Typography>
                <LinearProgress variant="determinate" value={Math.round(uploadProgress * 100)} />
              </Box>
            )}

            {warningKey && <Alert severity="warning">{t(warningKey)}</Alert>}
            {errorKey && (
              <Alert severity="error">
                {t(errorKey)}
                {errorKey === "capture-mobile-mic-denied" && (
                  <Typography variant="body2" component="span" className="mt-1 block text-xs leading-5">
                    {t("capture-mobile-mic-denied-help")}
                  </Typography>
                )}
              </Alert>
            )}

            <Box className="flex flex-col gap-2">
              {phase === "idle" &&
                (resolved?.audioAvailable ? (
                  <Button
                    variant="contained"
                    size="large"
                    fullWidth
                    color="primary"
                    startIcon={<NiMicrophone size="tiny" />}
                    onClick={() => void start()}
                  >
                    {t("recorder-start")}
                  </Button>
                ) : (
                  // Audio needs consent + minutes; a free workspace has neither,
                  // but photos below still work. State it, do not block.
                  <Alert severity="info">{t("capture-audio-unavailable")}</Alert>
                ))}
              {phase === "error" && (
                <Button
                  variant="contained"
                  size="large"
                  fullWidth
                  color="primary"
                  startIcon={<NiMicrophone size="tiny" />}
                  onClick={pendingBlob.current ? retryUpload : () => void start()}
                >
                  {pendingBlob.current ? t("recorder-retry-upload") : t("recorder-start")}
                </Button>
              )}
              {phase === "recording" && (
                <Box className="flex flex-row gap-2">
                  <Button
                    variant="outlined"
                    size="large"
                    color="grey"
                    className="flex-1"
                    startIcon={<NiPause size="tiny" />}
                    onClick={pause}
                  >
                    {t("recorder-pause")}
                  </Button>
                  <Button
                    variant="contained"
                    size="large"
                    color="primary"
                    className="flex-1"
                    startIcon={<NiSquare size="tiny" />}
                    onClick={finish}
                  >
                    {t("recorder-finish")}
                  </Button>
                </Box>
              )}
              {phase === "paused" && (
                <Box className="flex flex-row gap-2">
                  <Button
                    variant="outlined"
                    size="large"
                    color="grey"
                    className="flex-1"
                    startIcon={<NiMicrophone size="tiny" />}
                    onClick={resume}
                  >
                    {t("recorder-resume")}
                  </Button>
                  <Button
                    variant="contained"
                    size="large"
                    color="primary"
                    className="flex-1"
                    startIcon={<NiSquare size="tiny" />}
                    onClick={finish}
                  >
                    {t("recorder-finish")}
                  </Button>
                </Box>
              )}
            </Box>

            {resolved?.audioAvailable && (
              <Typography variant="body2" className="text-text-secondary text-xs leading-5">
                {t("capture-mobile-note")}
              </Typography>
            )}
          </>
        )}

        {/* Photo / document — the SAME QR session. Hidden while audio records,
            so opening the camera never fights the microphone for the device. */}
        {(phase === "idle" || phase === "done" || phase === "recovered") && (
          <Box className="border-grey-100 flex flex-col gap-2 border-t pt-4">
            <Typography variant="body2" className="text-text-primary font-medium">
              {t("capture-photo-title")}
            </Typography>
            <Typography variant="body2" className="text-text-secondary text-xs leading-5">
              {t("capture-photo-hint")}
            </Typography>
            <input
              ref={photoInput}
              type="file"
              accept="image/*"
              capture="environment"
              className="hidden"
              onChange={(event) => void sendAttachments(event.target.files)}
            />
            <input
              ref={fileInput}
              type="file"
              accept="image/*,application/pdf"
              multiple
              className="hidden"
              onChange={(event) => void sendAttachments(event.target.files)}
            />
            {attachError && (
              <Alert severity={attachError === "capture-photo-consent" ? "info" : "error"}>{t(attachError)}</Alert>
            )}
            {attachments.length > 0 && (
              <>
                <Alert severity="success" icon={<NiCheckSquare />}>
                  {t("capture-photo-sent", { count: attachments.length })}
                </Alert>
                {/* What was sent, shown rather than counted: on a phone, "1
                    anexo enviado" cannot tell her she photographed the tongue
                    and not the ceiling. A document has no useful preview, so it
                    is identified by its name instead. */}
                <Box component="ul" className="m-0 flex list-none flex-row flex-wrap gap-2 p-0">
                  {attachments.map((attachment) => (
                    <Box component="li" key={attachment.id} className="flex w-16 flex-col items-center gap-1">
                      {attachment.previewUrl ? (
                        // A local blob URL — next/image cannot optimize it and
                        // would only add a proxy hop for bytes already here.
                        <img
                          src={attachment.previewUrl}
                          alt={attachment.name}
                          className="border-grey-100 h-16 w-16 rounded-xl border object-cover"
                        />
                      ) : (
                        <Box
                          aria-hidden
                          className="border-grey-100 bg-grey-25 text-text-secondary flex h-16 w-16 items-center justify-center rounded-xl border"
                        >
                          <NiDocumentFull size="medium" />
                        </Box>
                      )}
                      {!attachment.isImage && (
                        <Typography
                          variant="body2"
                          className="text-text-secondary w-full truncate text-center text-[0.625rem] leading-4"
                        >
                          {attachment.name}
                        </Typography>
                      )}
                    </Box>
                  ))}
                </Box>
              </>
            )}
            <Box className="flex flex-row gap-2">
              <Button
                variant="outlined"
                color="primary"
                className="flex-1"
                startIcon={<NiCamera size="tiny" />}
                disabled={attaching}
                onClick={() => photoInput.current?.click()}
              >
                {t("capture-photo-take")}
              </Button>
              <Button
                variant="outlined"
                color="grey"
                className="flex-1"
                disabled={attaching}
                onClick={() => fileInput.current?.click()}
              >
                {t("capture-photo-upload")}
              </Button>
            </Box>
            {attaching && <LinearProgress />}
          </Box>
        )}
      </CardContent>
    </Card>
  );
}
