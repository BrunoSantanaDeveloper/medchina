// Fallback stub — replace with a real phosphor adapter when needed.
export { default } from "../nexture/ni-arrow-out-up";
