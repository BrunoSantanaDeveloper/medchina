import {
  aboutEvent,
  addEventToken,
  deviceFromUserAgent,
  EVENT_COOKIE_MAX_TOKENS,
  eventPath,
  isEventSlug,
  isSafeInternalPath,
  parseEventCookie,
  readEventTopics,
  slugFromTitle,
  topicsCountLabel,
} from "./live-event-common";
import { describe, expect, it } from "vitest";

const token = (seed: string) => seed.repeat(43).slice(0, 43);

describe("eventPath", () => {
  it("keeps the first event at its published address", () => {
    expect(eventPath("lei-15345")).toBe("/lei-15345");
  });
  it("puts every other event under /ao-vivo", () => {
    expect(eventPath("masterclass-fertilidade")).toBe("/ao-vivo/masterclass-fertilidade");
  });
});

describe("slugs", () => {
  it("suggests a slug from a Portuguese title", () => {
    expect(slugFromTitle("Masterclass: Fertilidade na MTC — ao vivo!")).toBe("masterclass-fertilidade-na-mtc-ao-vivo");
    expect(slugFromTitle("Ação e Reação")).toBe("acao-e-reacao");
  });
  it("accepts only the database shape", () => {
    expect(isEventSlug("lei-15345")).toBe(true);
    expect(isEventSlug("ab")).toBe(false);
    expect(isEventSlug("-abc")).toBe(false);
    expect(isEventSlug("Abc")).toBe(false);
    expect(isEventSlug("a/b")).toBe(false);
  });
});

describe("aboutEvent", () => {
  it("uses the topic inside the sentence", () => {
    expect(aboutEvent({ title: "Qualquer", topic: "a Lei 15.345" })).toBe("sobre a Lei 15.345");
  });
  it("falls back to the quoted title", () => {
    expect(aboutEvent({ title: "Fertilidade na MTC", topic: null })).toBe("“Fertilidade na MTC”");
  });
});

describe("registration cookie", () => {
  it("reads a legacy single-token cookie", () => {
    expect(parseEventCookie(token("a"))).toEqual([token("a")]);
  });
  it("drops malformed and repeated parts", () => {
    expect(parseEventCookie(`${token("a")}.nope.${token("a")}.${token("b")}`)).toEqual([token("a"), token("b")]);
  });
  it("adds the newest first without duplicating", () => {
    const value = addEventToken(`${token("a")}.${token("b")}`, token("b"));
    expect(parseEventCookie(value)).toEqual([token("b"), token("a")]);
  });
  it("stays bounded", () => {
    let value = "";
    for (const seed of "abcdefghij") value = addEventToken(value, token(seed));
    expect(parseEventCookie(value)).toHaveLength(EVENT_COOKIE_MAX_TOKENS);
    expect(parseEventCookie(value)[0]).toBe(token("j"));
  });
  it("ignores a malformed token instead of storing it", () => {
    expect(addEventToken(token("a"), "short")).toBe(token("a"));
  });
});

describe("deviceFromUserAgent", () => {
  it("tells a phone from a computer", () => {
    expect(
      deviceFromUserAgent(
        "Mozilla/5.0 (Linux; Android 14; SM-A145M) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36",
      ),
    ).toBe("phone");
    expect(deviceFromUserAgent("Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X)")).toBe("phone");
    expect(deviceFromUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/140.0.0.0 Safari/537.36")).toBe(
      "computer",
    );
    expect(deviceFromUserAgent(null)).toBe("computer");
  });
});

describe("isSafeInternalPath", () => {
  it("accepts addresses of this site", () => {
    expect(isSafeInternalPath("/")).toBe(true);
    expect(isSafeInternalPath("/china")).toBe(true);
    expect(isSafeInternalPath("/ao-vivo/proximo")).toBe(true);
    expect(isSafeInternalPath("/assinar?origem=gravacao&utm_campaign=x")).toBe(true);
  });
  it("refuses anything that leaves it", () => {
    expect(isSafeInternalPath("//evil.example")).toBe(false);
    expect(isSafeInternalPath("https://evil.example")).toBe(false);
    expect(isSafeInternalPath("/\\evil.example")).toBe(false);
    expect(isSafeInternalPath("javascript:alert(1)")).toBe(false);
    expect(isSafeInternalPath("china")).toBe(false);
    expect(isSafeInternalPath("")).toBe(false);
  });
});

describe("topics", () => {
  it("keeps well-formed items, at most three", () => {
    const topics = readEventTopics([
      { icon: "lei", text: "A" },
      { icon: "nope", text: "B" },
      { icon: "video", text: "  " },
      { icon: "livro", text: "C" },
      { icon: "folha", text: "D" },
      { icon: "grafico", text: "E" },
    ]);
    expect(topics.map((item) => item.text)).toEqual(["A", "C", "D"]);
    expect(readEventTopics("nope")).toEqual([]);
  });
  it("counts in words", () => {
    expect(topicsCountLabel(1)).toBe("um assunto");
    expect(topicsCountLabel(3)).toBe("três assuntos");
  });
});
