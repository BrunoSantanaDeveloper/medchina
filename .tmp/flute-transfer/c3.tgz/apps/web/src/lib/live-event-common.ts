/**
 * What the live-event pages, their public routes and the console must agree on
 * — pure, dependency-free, safe on the client (docs/PAGINA-EVENTO.md; migration
 * 0113). The server-only half (tokens, hashing, the service client) lives in
 * `live-event-shared.ts` / `live-event.ts`.
 */

/** The slug shape the database CHECK enforces (`live_events.slug`). */
export const EVENT_SLUG_SHAPE = /^[a-z0-9][a-z0-9-]{2,59}$/;

export function isEventSlug(value: unknown): value is string {
  return typeof value === "string" && EVENT_SLUG_SHAPE.test(value);
}

/**
 * Events published before the generic route existed keep their own address:
 * `/lei-15345` is printed in e-mails, ads and QR codes already. Every other
 * event lives under `/ao-vivo/<slug>`.
 */
export const LEGACY_EVENT_PATHS: Readonly<Record<string, string>> = { "lei-15345": "/lei-15345" };

export function eventPath(slug: string): string {
  return LEGACY_EVENT_PATHS[slug] ?? `/ao-vivo/${slug}`;
}

/** A suggested slug for a title: lower case, no accents, words joined by "-". */
export function slugFromTitle(title: string): string {
  return title
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60)
    .replace(/-+$/g, "");
}

// ---------- How the event is named in a sentence ----------

export type EventNaming = { title: string; topic: string | null };

/**
 * "no ao vivo sobre a Lei 15.345" with a topic, "no ao vivo “Título”" without
 * one — the phrase every message about the event builds on (e-mail subjects,
 * the WhatsApp messages, the console's 1:1).
 */
export function aboutEvent(event: EventNaming): string {
  const topic = event.topic?.trim();
  return topic ? `sobre ${topic}` : `“${event.title.trim()}”`;
}

// ---------- The registration cookie ----------

/**
 * One cookie holds the tokens of every event this browser registered for,
 * newest first, joined by "." (base64url never contains it). One slot per
 * event would ping-pong: registering for a second event overwrote the first
 * and the first page stopped recognizing her. Bounded, so an old token falls
 * off instead of growing the header.
 */
export const EVENT_COOKIE_MAX_TOKENS = 6;

const TOKEN_SHAPE = /^[A-Za-z0-9_-]{43}$/;

export function parseEventCookie(value: string | null | undefined): string[] {
  if (!value) return [];
  const seen = new Set<string>();
  const tokens: string[] = [];
  for (const part of value.split(".")) {
    if (TOKEN_SHAPE.test(part) && !seen.has(part)) {
      seen.add(part);
      tokens.push(part);
    }
    if (tokens.length === EVENT_COOKIE_MAX_TOKENS) break;
  }
  return tokens;
}

export function addEventToken(value: string | null | undefined, token: string): string {
  if (!TOKEN_SHAPE.test(token)) return parseEventCookie(value).join(".");
  return [token, ...parseEventCookie(value).filter((existing) => existing !== token)]
    .slice(0, EVENT_COOKIE_MAX_TOKENS)
    .join(".");
}

// ---------- Device of the group click ----------

/**
 * Phone or computer, from the user agent — the only thing kept about the
 * device. A tablet counts as a phone: it has the WhatsApp app.
 */
export function deviceFromUserAgent(userAgent: string | null | undefined): "phone" | "computer" {
  if (!userAgent) return "computer";
  return /android|iphone|ipad|ipod|mobile|windows phone|opera mini|iemobile/i.test(userAgent) ? "phone" : "computer";
}

// ---------- After the event ----------

/** Same rule as the database CHECK: an address of THIS site, never a scheme or "//host". */
export function isSafeInternalPath(value: string | null | undefined): value is string {
  return typeof value === "string" && value.length <= 200 && /^\/([A-Za-z0-9_-][A-Za-z0-9/_.~%=&?#-]*)?$/.test(value);
}

// ---------- Page content ----------

export const TOPIC_ICON_KEYS = [
  "lei",
  "apresentacao",
  "consulta",
  "conversa",
  "livro",
  "grafico",
  "pessoas",
  "coracao",
  "folha",
  "video",
] as const;

export type TopicIconKey = (typeof TOPIC_ICON_KEYS)[number];

export type EventTopic = { icon: TopicIconKey; text: string };

export const TOPIC_ICON_LABELS: Record<TopicIconKey, string> = {
  lei: "Lei, norma",
  apresentacao: "Apresentação",
  consulta: "Consulta, demonstração",
  conversa: "Conversa, perguntas",
  livro: "Estudo, livro",
  grafico: "Números, gráfico",
  pessoas: "Pessoas, comunidade",
  coracao: "Cuidado",
  folha: "Natureza, fitoterapia",
  video: "Vídeo",
};

/** The topics column, trusted only as far as its shape: anything malformed is dropped. */
export function readEventTopics(value: unknown): EventTopic[] {
  if (!Array.isArray(value)) return [];
  return value
    .filter(
      (item): item is EventTopic =>
        Boolean(item) &&
        typeof item === "object" &&
        (TOPIC_ICON_KEYS as readonly string[]).includes((item as EventTopic).icon) &&
        typeof (item as EventTopic).text === "string" &&
        (item as EventTopic).text.trim().length > 0,
    )
    .slice(0, 3);
}

/** "um assunto" / "dois assuntos" / "três assuntos". */
export function topicsCountLabel(count: number): string {
  return ["", "um assunto", "dois assuntos", "três assuntos"][count] ?? `${count} assuntos`;
}

export const DEFAULT_BYLINE = "com Debora Giovanella, fundadora do MedChina";

/** The same limits as `live_events_content_lengths` (migration 0113). */
export const EVENT_CONTENT_LIMITS = {
  title: 200,
  topic: 80,
  headline: 220,
  byline: 140,
  lead: 600,
  audienceHeading: 140,
  audience: 600,
  description: 200,
  topicText: 200,
} as const;
