-- ---------------------------------------------------------------------------
-- 0113 — Eventos ao vivo: vários eventos, página por modelo, resultados por evento
-- ---------------------------------------------------------------------------
-- 0112 modelled many events (one row each, registrations keyed by event) but
-- the product around it assumed one: a hardcoded page, routes that loaded the
-- first event by slug, one cookie slot, e-mail subjects naming Lei 15.345, and
-- no way to create an event without SQL. This migration gives the console what
-- it needs to run events one after another, each with its own page and its own
-- results:
--
--   1. The page's CONTENT is data on the event (headline, lead, topics,
--      audience, link-preview description) rendered by one Landing DS
--      template, so a new event is a console action, not a deploy. Partners
--      have NO registry of their own (owner's decision, 2026-09-28): a partner
--      is named in the event's own byline and copy.
--   2. What an ENDED event's page does is a per-event choice made in the
--      console: keep showing the recording with the short capture, or redirect
--      to another address of this site.
--   3. Lifecycle rules live in the database, not only in the screen: an event
--      is created as a draft; its slug freezes once it leaves the draft or has
--      a registration (it is printed in e-mails, ads and QR codes); only an
--      empty draft can be deleted; anything else is archived.
--   4. Per-event results need three facts 0112 did not keep: page visits by
--      channel (counted server-side, no personal data), the device of the group
--      click (the spec splits that rate by phone and computer), and the
--      purchases each campaign produced — `meta_attribution` is one row per
--      workspace, rewritten by the next checkout, so a durable record is kept
--      per paid invoice.

-- ---------- Event content and lifecycle ----------

alter table public.live_events
  -- "a Lei 15.345": how the event is named inside a sentence — "o ao vivo sobre
  -- ___" in e-mail subjects and WhatsApp messages.
  add column if not exists topic text,
  -- The page's h1. `**accent**` marks the emphasized tail (the DS <em>).
  add column if not exists headline text,
  add column if not exists byline text not null default 'com Debora Giovanella, fundadora do MedChina',
  add column if not exists lead text,
  -- Optional: the same lead in the past tense, shown once the event is over.
  add column if not exists lead_after text,
  -- Up to three "what you will see" items: [{ "icon": "<key>", "text": "…" }].
  add column if not exists topics jsonb not null default '[]'::jsonb,
  add column if not exists audience_heading text,
  add column if not exists audience text,
  -- Page description and link preview (WhatsApp shows it under the title).
  add column if not exists description text,
  add column if not exists ended_behavior text not null default 'recording',
  add column if not exists ended_redirect_path text,
  add column if not exists archived_at timestamptz;

create or replace function public.live_event_topics_valid(value jsonb)
returns boolean
language sql
immutable
set search_path = public
as $$
  -- CASE, not AND/OR: SQL does not promise evaluation order, and
  -- jsonb_array_length / jsonb_object_keys raise on the wrong type instead of
  -- answering false.
  select case
    when jsonb_typeof(value) is distinct from 'array' then false
    when jsonb_array_length(value) > 3 then false
    else not exists (
      select 1
      from jsonb_array_elements(value) item
      where case
        when jsonb_typeof(item) <> 'object' then true
        when (select count(*) from jsonb_object_keys(item)) <> 2 then true
        when coalesce(item ->> 'icon', '') not in (
          'lei', 'apresentacao', 'consulta', 'conversa', 'livro', 'grafico', 'pessoas', 'coracao', 'folha', 'video'
        ) then true
        when char_length(btrim(coalesce(item ->> 'text', ''))) not between 1 and 200 then true
        else false
      end
    )
  end;
$$;

alter table public.live_events drop constraint if exists live_events_content_lengths;
alter table public.live_events add constraint live_events_content_lengths check (
  (topic is null or char_length(btrim(topic)) between 1 and 80)
  and (headline is null or char_length(btrim(headline)) between 1 and 220)
  and char_length(btrim(byline)) between 1 and 140
  and (lead is null or char_length(lead) <= 600)
  and (lead_after is null or char_length(lead_after) <= 600)
  and (audience_heading is null or char_length(audience_heading) <= 140)
  and (audience is null or char_length(audience) <= 600)
  and (description is null or char_length(description) <= 200)
);

alter table public.live_events drop constraint if exists live_events_topics_shape;
alter table public.live_events add constraint live_events_topics_shape check (public.live_event_topics_valid(topics));

-- The redirect is an address of THIS site: a path, never a scheme or a
-- protocol-relative "//host" (an open redirect with our domain on it).
alter table public.live_events drop constraint if exists live_events_ended_behavior;
alter table public.live_events add constraint live_events_ended_behavior check (
  ended_behavior in ('recording', 'redirect')
  and (
    ended_redirect_path is null
    or (char_length(ended_redirect_path) <= 200 and ended_redirect_path ~ '^/([A-Za-z0-9_-][A-Za-z0-9/_.~%=&?#-]*)?$')
  )
  and (ended_behavior = 'recording' or ended_redirect_path is not null)
);

-- Only what is not running can be put away: a draft nobody will publish, or an
-- event that is over. An archived event keeps its page behaviour and its data.
alter table public.live_events drop constraint if exists live_events_archive_state;
alter table public.live_events add constraint live_events_archive_state check (
  archived_at is null or state in ('rascunho', 'encerrado')
);

-- The slug is the address. Once the event is published, or someone registered,
-- it is printed in e-mails, ads and QR codes: renaming it would break them all.
create or replace function public.live_events_guard_slug()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  if new.slug is distinct from old.slug
     and (old.state <> 'rascunho'
          or exists (select 1 from public.live_event_registrations r where r.event_id = old.id)) then
    raise exception 'live_event_slug_locked' using errcode = 'check_violation';
  end if;
  return new;
end;
$$;

drop trigger if exists live_events_guard_slug on public.live_events;
create trigger live_events_guard_slug
  before update on public.live_events
  for each row execute function public.live_events_guard_slug();

-- The first event keeps exactly the page it had (0112 rendered it from code).
-- "Este encontro" replaces "esta noite"/"esta gravação": one text that reads
-- right before and after the live.
update public.live_events
set topic = 'a Lei 15.345',
    headline = 'O que muda para o acupunturista brasileiro depois da Lei 15.345 **e o que eu vi na China.**',
    lead = 'Em janeiro, a acupuntura virou profissão regulamentada no Brasil. Em setembro, eu levei o MedChina ao Congresso de MTC em Xinjiang, na China. Nesta noite eu conto as duas coisas, e o que elas mudam no seu consultório.',
    lead_after = 'Em janeiro, a acupuntura virou profissão regulamentada no Brasil. Em setembro, eu levei o MedChina ao Congresso de MTC em Xinjiang, na China. No ao vivo eu contei as duas coisas, e o que elas mudam no seu consultório.',
    topics = '[
      {"icon": "lei", "text": "Quem pode exercer a acupuntura segundo a Lei 15.345, e o que muda na prática do consultório depois dela"},
      {"icon": "apresentacao", "text": "O que eu apresentei no Congresso de MTC em Xinjiang, e o que vi por lá"},
      {"icon": "consulta", "text": "Uma consulta simulada, com paciente e diálogo fictícios, registrada do começo ao fim sem ninguém digitar durante o atendimento"}
    ]'::jsonb,
    audience_heading = 'Para quem registra **o que atende.**',
    audience = 'Para quem atende com acupuntura ou MTC e registra as consultas — em papel, em caderno, em qualquer sistema. Se você nunca registrou nada e não pretende começar, este encontro não vai te servir.',
    description = 'Debora Giovanella, fundadora do MedChina, conta ao vivo o que muda para o acupunturista brasileiro depois da Lei 15.345 e o que viu no Congresso de MTC em Xinjiang, na China.'
where slug = 'lei-15345' and headline is null;

-- ---------- Duplicate / delete ----------

-- Copies what describes the event (content, owner number, limits, behaviour
-- after it ends) — never its registrations, date, state, stream or recording,
-- which belong to the edition that happened.
create or replace function public.duplicate_live_event(target_event uuid, target_slug text, target_title text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  source public.live_events%rowtype;
  new_id uuid;
begin
  if not public.is_superadmin() then
    return jsonb_build_object('ok', false, 'code', 'not_authorized');
  end if;
  select * into source from public.live_events where id = target_event;
  if source.id is null then
    return jsonb_build_object('ok', false, 'code', 'not_found');
  end if;
  if coalesce(target_slug, '') !~ '^[a-z0-9][a-z0-9-]{2,59}$' then
    return jsonb_build_object('ok', false, 'code', 'invalid_slug');
  end if;
  if exists (select 1 from public.live_events where slug = target_slug) then
    return jsonb_build_object('ok', false, 'code', 'slug_taken');
  end if;
  if char_length(btrim(coalesce(target_title, ''))) not between 1 and 200 then
    return jsonb_build_object('ok', false, 'code', 'invalid_title');
  end if;

  insert into public.live_events (
    slug, title, state, duration_minutes, owner_phone, ip_window_limit,
    topic, headline, byline, lead, lead_after, topics, audience_heading, audience, description,
    ended_behavior, ended_redirect_path, updated_by
  ) values (
    target_slug, btrim(target_title), 'rascunho', source.duration_minutes, source.owner_phone, source.ip_window_limit,
    source.topic, source.headline, source.byline, source.lead, source.lead_after, source.topics,
    source.audience_heading, source.audience, source.description,
    source.ended_behavior, source.ended_redirect_path, auth.uid()
  )
  returning id into new_id;

  insert into public.audit_events (org_id, actor_id, action, entity_type, entity_id, metadata)
  values (null, auth.uid(), 'admin.events.duplicated', 'live_event', new_id::text,
          jsonb_build_object('source', source.slug, 'slug', target_slug));

  return jsonb_build_object('ok', true, 'id', new_id);
end;
$$;

revoke all on function public.duplicate_live_event(uuid, text, text) from public, anon;
grant execute on function public.duplicate_live_event(uuid, text, text) to authenticated;

-- Delete is for a draft nobody reached. A published event, or one with any
-- registration, holds consent evidence and results: it is archived instead
-- (and the FK from registrations refuses the delete anyway).
create or replace function public.delete_live_event(target_event uuid, target_reason text default null)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  ev public.live_events%rowtype;
begin
  if not public.is_superadmin() then
    return jsonb_build_object('ok', false, 'code', 'not_authorized');
  end if;
  select * into ev from public.live_events where id = target_event for update;
  if ev.id is null then
    return jsonb_build_object('ok', false, 'code', 'not_found');
  end if;
  if ev.state <> 'rascunho' then
    return jsonb_build_object('ok', false, 'code', 'not_draft');
  end if;
  if exists (select 1 from public.live_event_registrations where event_id = ev.id) then
    return jsonb_build_object('ok', false, 'code', 'has_registrations');
  end if;

  delete from public.live_events where id = ev.id;

  insert into public.audit_events (org_id, actor_id, action, entity_type, entity_id, metadata)
  values (null, auth.uid(), 'admin.events.deleted', 'live_event', ev.id::text,
          case when nullif(btrim(target_reason), '') is null then jsonb_build_object('slug', ev.slug)
               else jsonb_build_object('slug', ev.slug, 'reason', left(btrim(target_reason), 500)) end);

  return jsonb_build_object('ok', true);
end;
$$;

revoke all on function public.delete_live_event(uuid, text) from public, anon;
grant execute on function public.delete_live_event(uuid, text) to authenticated;

-- ---------- Device of the group click ----------
-- The spec splits "clicked the group ÷ registered" by phone and computer: on a
-- computer without WhatsApp Desktop the number measures the device, not the
-- button. Only the class is kept, never the user agent.

alter table public.live_event_registrations
  add column if not exists group_clicked_device text
    check (group_clicked_device is null or group_clicked_device in ('phone', 'computer'));

drop function if exists public.touch_live_event_registration(text, text, integer);

create or replace function public.touch_live_event_registration(
  target_token_hash text,
  target_kind text,
  target_seconds integer default 0,
  target_device text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  reg uuid;
  ev_slug text;
  ev_state text;
begin
  if auth.role() is distinct from 'service_role' then
    return jsonb_build_object('ok', false, 'code', 'not_authorized');
  end if;
  if coalesce(target_token_hash, '') !~ '^[0-9a-f]{64}$'
     or target_kind is null or target_kind not in ('group', 'whatsapp', 'presence')
     or (target_device is not null and target_device not in ('phone', 'computer')) then
    return jsonb_build_object('ok', false, 'code', 'invalid_request');
  end if;

  select t.registration_id, e.slug, e.state into reg, ev_slug, ev_state
    from public.live_event_tokens t
    join public.live_event_registrations r on r.id = t.registration_id
    join public.live_events e on e.id = r.event_id
    where t.token_hash = target_token_hash and t.expires_at > now();
  if reg is null then
    return jsonb_build_object('ok', false, 'code', 'not_found');
  end if;

  -- Presence is attendance AT the live (docs/PAGINA-EVENTO.md §14).
  if target_kind = 'presence' and ev_state is distinct from 'ao_vivo' then
    return jsonb_build_object('ok', false, 'code', 'not_live');
  end if;

  if target_kind = 'group' then
    update public.live_event_registrations
       set group_clicked_at = now(), group_clicked_device = target_device
     where id = reg and group_clicked_at is null;
  elsif target_kind = 'whatsapp' then
    update public.live_event_registrations set whatsapp_started_at = now()
      where id = reg and whatsapp_started_at is null;
  else
    -- A heartbeat reports at most two minutes, whatever the client claims.
    insert into public.live_event_presence (registration_id)
    values (reg)
    on conflict (registration_id) do update
      set last_seen_at = now(),
          watched_seconds = least(
            86400,
            public.live_event_presence.watched_seconds + greatest(0, least(coalesce(target_seconds, 0), 120))
          );
  end if;

  return jsonb_build_object('ok', true, 'registration_id', reg, 'event_slug', ev_slug);
end;
$$;

revoke all on function public.touch_live_event_registration(text, text, integer, text) from public, anon, authenticated;
grant execute on function public.touch_live_event_registration(text, text, integer, text) to service_role;

-- ---------- Page visits ----------
-- Counted by the page's server render (crawlers, drafts and operators excluded),
-- per event, per day in Brasília, per channel. A counter, not a log: no IP, no
-- user agent, no person — "registered ÷ visited" by channel is all it answers.

create table if not exists public.live_event_page_views (
  event_id uuid not null references public.live_events (id) on delete cascade,
  day date not null,
  origem text not null default '' check (char_length(origem) <= 64),
  views integer not null default 0 check (views >= 0),
  primary key (event_id, day, origem)
);

alter table public.live_event_page_views enable row level security;

drop policy if exists "live_event_page_views_select_superadmin" on public.live_event_page_views;
create policy "live_event_page_views_select_superadmin" on public.live_event_page_views
  for select to authenticated
  using (public.is_superadmin());

revoke all on table public.live_event_page_views from anon;
revoke insert, update, delete, truncate on table public.live_event_page_views from authenticated;

create or replace function public.count_live_event_view(target_slug text, target_origem text default null)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  ev_id uuid;
  channel text := left(btrim(coalesce(target_origem, '')), 64);
begin
  if auth.role() is distinct from 'service_role' then
    return;
  end if;
  select id into ev_id from public.live_events where slug = target_slug and state <> 'rascunho';
  if ev_id is null then
    return;
  end if;
  insert into public.live_event_page_views (event_id, day, origem, views)
  values (ev_id, (now() at time zone 'America/Sao_Paulo')::date, channel, 1)
  on conflict (event_id, day, origem) do update
    set views = public.live_event_page_views.views + 1;
end;
$$;

revoke all on function public.count_live_event_view(text, text) from public, anon, authenticated;
grant execute on function public.count_live_event_view(text, text) to service_role;

-- ---------- Purchases per campaign ----------
-- One row per paid invoice that STARTED a subscription with a last-touch
-- campaign captured at its checkout (the billing webhook writes it). It is
-- what "how many purchases did this event produce?" reads: meta_attribution
-- keeps only the latest checkout per workspace, and the Purchase sent to Meta
-- does not come back. Business facts only — workspace, plan, amount, campaign.

create table if not exists public.purchase_attributions (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  org_id uuid not null references public.organizations (id) on delete cascade,
  invoice_key text not null unique check (char_length(invoice_key) <= 200),
  subscription_id uuid,
  plan_slug text check (plan_slug is null or char_length(plan_slug) <= 80),
  amount_cents integer not null check (amount_cents >= 0),
  currency text not null check (char_length(currency) between 3 and 8),
  paid_at timestamptz not null,
  origem text,
  utm_source text,
  utm_medium text,
  utm_campaign text,
  utm_content text,
  campaign_captured_at timestamptz,
  constraint purchase_attributions_lengths check (
    coalesce(length(origem), 0) <= 64
    and coalesce(length(utm_source), 0) <= 64
    and coalesce(length(utm_medium), 0) <= 64
    and coalesce(length(utm_campaign), 0) <= 64
    and coalesce(length(utm_content), 0) <= 64
  )
);

create index if not exists purchase_attributions_campaign_idx
  on public.purchase_attributions (utm_campaign, paid_at desc);
create index if not exists purchase_attributions_org_idx
  on public.purchase_attributions (org_id);

alter table public.purchase_attributions enable row level security;

drop policy if exists "purchase_attributions_select_superadmin" on public.purchase_attributions;
create policy "purchase_attributions_select_superadmin" on public.purchase_attributions
  for select to authenticated
  using (public.is_superadmin());

revoke all on table public.purchase_attributions from anon;
revoke insert, update, delete, truncate on table public.purchase_attributions from authenticated;

-- ---------- Results ----------
-- Security INVOKER on purpose: RLS is the gate (every table read here is
-- superadmin-only), so a non-operator gets empty answers, never another
-- workspace's numbers.

create or replace function public.live_events_overview()
returns table (
  id uuid,
  slug text,
  title text,
  state text,
  starts_at timestamptz,
  archived_at timestamptz,
  updated_at timestamptz,
  registrations integer,
  present integer,
  visits integer,
  purchases integer
)
language sql
stable
security invoker
set search_path = public
as $$
  select
    e.id, e.slug, e.title, e.state, e.starts_at, e.archived_at, e.updated_at,
    (select count(*)::int from public.live_event_registrations r where r.event_id = e.id),
    (select count(*)::int from public.live_event_registrations r
       join public.live_event_presence p on p.registration_id = r.id where r.event_id = e.id),
    (select coalesce(sum(v.views), 0)::int from public.live_event_page_views v where v.event_id = e.id),
    (select count(*)::int from public.purchase_attributions a where a.utm_campaign = e.slug)
  from public.live_events e
  where public.is_superadmin()
  order by coalesce(e.starts_at, e.created_at) desc;
$$;

revoke all on function public.live_events_overview() from public, anon;
grant execute on function public.live_events_overview() to authenticated;

create or replace function public.live_event_results(target_event uuid)
returns jsonb
language plpgsql
stable
security invoker
set search_path = public
as $$
declare
  ev public.live_events%rowtype;
  result jsonb;
begin
  if not public.is_superadmin() then
    return jsonb_build_object('ok', false, 'code', 'not_authorized');
  end if;
  select * into ev from public.live_events where id = target_event;
  if ev.id is null then
    return jsonb_build_object('ok', false, 'code', 'not_found');
  end if;

  select jsonb_build_object(
    'ok', true,
    'registrations', count(*),
    'after_event', count(*) filter (where r.after_event),
    'group_clicked', count(*) filter (where r.group_clicked_at is not null),
    'group_phone', count(*) filter (where r.group_clicked_device = 'phone'),
    'group_computer', count(*) filter (where r.group_clicked_device = 'computer'),
    'whatsapp_started', count(*) filter (where r.whatsapp_started_at is not null),
    'present', count(*) filter (where p.registration_id is not null),
    'watched_20', count(*) filter (where coalesce(p.watched_seconds, 0) >= 1200),
    'emails', jsonb_build_object(
      'confirmation', count(*) filter (where r.email_confirmation_sent_at is not null),
      'day_before', count(*) filter (where r.email_day_before_sent_at is not null),
      'hour_before', count(*) filter (where r.email_hour_before_sent_at is not null),
      'live', count(*) filter (where r.email_live_sent_at is not null),
      'recording', count(*) filter (where r.email_recording_sent_at is not null)
    )
  )
  into result
  from public.live_event_registrations r
  left join public.live_event_presence p on p.registration_id = r.id
  where r.event_id = ev.id;

  result := result || jsonb_build_object(
    'visits', coalesce((select sum(views) from public.live_event_page_views where event_id = ev.id), 0),
    'channels', coalesce((
      select jsonb_agg(
        jsonb_build_object('channel', channel, 'visits', visits, 'registrations', registrations)
        order by registrations desc, visits desc, channel
      )
      from (
        select channel, sum(visits)::int as visits, sum(registrations)::int as registrations
        from (
          select coalesce(nullif(v.origem, ''), 'direto') as channel, v.views as visits, 0 as registrations
            from public.live_event_page_views v where v.event_id = ev.id
          union all
          select coalesce(nullif(r.origem, ''), nullif(r.utm_source, ''), 'direto'), 0, 1
            from public.live_event_registrations r where r.event_id = ev.id
        ) rows
        group by channel
      ) channels
    ), '[]'::jsonb),
    'purchases', (select count(*) from public.purchase_attributions a where a.utm_campaign = ev.slug),
    'revenue_cents', coalesce((select sum(amount_cents) from public.purchase_attributions a where a.utm_campaign = ev.slug), 0)
  );

  return result;
end;
$$;

revoke all on function public.live_event_results(uuid) from public, anon;
grant execute on function public.live_event_results(uuid) to authenticated;
