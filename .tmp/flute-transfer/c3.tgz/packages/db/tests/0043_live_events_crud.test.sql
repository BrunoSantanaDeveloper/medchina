begin;
create extension if not exists pgtap with schema extensions;
select plan(35);

-- ============================================================
-- Migration 0113 — many live events: page content as data, per-event results,
-- and the lifecycle rules the console relies on.
--
-- Four promises: a new event never touches another's data; the address of a
-- published event cannot move; only an empty draft can be deleted; and the
-- results (visits, device of the group click, purchases) are counted without
-- a single personal datum and read only by the operator.
-- ============================================================

-- ---------- Privileges ----------

select ok(not has_table_privilege('anon', 'public.live_event_page_views', 'SELECT'), 'anon cannot read page views');
select ok(not has_table_privilege('anon', 'public.purchase_attributions', 'SELECT'), 'anon cannot read purchase attributions');
select ok(not has_table_privilege('authenticated', 'public.purchase_attributions', 'INSERT'),
  'no signed-in user writes a purchase attribution (the webhook does)');
select ok(not has_table_privilege('authenticated', 'public.live_event_page_views', 'INSERT'),
  'no signed-in user writes page views (the page render does, as the server)');
select ok(
  not has_function_privilege('authenticated', 'public.count_live_event_view(text, text)', 'EXECUTE')
  and has_function_privilege('service_role', 'public.count_live_event_view(text, text)', 'EXECUTE'),
  'only the server counts a visit'
);
select ok(
  not has_function_privilege('anon', 'public.delete_live_event(uuid, text)', 'EXECUTE')
  and not has_function_privilege('anon', 'public.duplicate_live_event(uuid, text, text)', 'EXECUTE'),
  'anon cannot delete or duplicate events'
);
select ok(
  not has_function_privilege('authenticated', 'public.touch_live_event_registration(text, text, integer, text)', 'EXECUTE')
  and has_function_privilege('service_role', 'public.touch_live_event_registration(text, text, integer, text)', 'EXECUTE'),
  'the touch function keeps its server-only grant after the new signature'
);

-- ---------- The first event keeps its page ----------

select ok(
  (select topic = 'a Lei 15.345' and jsonb_array_length(topics) = 3 and headline like '%**e o que eu vi na China.**'
     and byline = 'com Debora Giovanella, fundadora do MedChina'
   from public.live_events where slug = 'lei-15345'),
  'the Lei 15.345 page content moved from code to its row, unchanged'
);

-- ---------- Fixtures ----------

insert into auth.users (
  id, instance_id, aud, role, email, encrypted_password,
  raw_app_meta_data, raw_user_meta_data, created_at, updated_at
) values
  ('f2000000-0000-4000-8000-000000000001', '00000000-0000-0000-0000-000000000000',
   'authenticated', 'authenticated', 'events-operator@medchina.invalid', '',
   '{}'::jsonb, '{"display_name":"Operator"}'::jsonb, now(), now()),
  ('f2000000-0000-4000-8000-000000000002', '00000000-0000-0000-0000-000000000000',
   'authenticated', 'authenticated', 'events-someone@medchina.invalid', '',
   '{}'::jsonb, '{"display_name":"Someone"}'::jsonb, now(), now());
update public.profiles set is_superadmin = true where id = 'f2000000-0000-4000-8000-000000000001';

insert into public.live_events (id, slug, title, state, starts_at, topic, headline)
values
  ('e1000000-0000-4000-8000-000000000001', 'teste-rascunho', 'Rascunho', 'rascunho', null, 'um teste', 'Manchete **teste.**'),
  ('e1000000-0000-4000-8000-000000000002', 'teste-publicado', 'Publicado', 'inscricoes', now() + interval '7 days', null, null),
  ('e1000000-0000-4000-8000-000000000003', 'teste-vazio', 'Vazio', 'rascunho', null, null, null);

insert into public.leads (id, name, phone) values ('d1000000-0000-4000-8000-000000000001', 'Ana', '62999991001');
insert into public.live_event_registrations (id, event_id, lead_id, contact_term_id, contact_term_version, contact_term_text, origem)
select 'c1000000-0000-4000-8000-000000000001', 'e1000000-0000-4000-8000-000000000002', 'd1000000-0000-4000-8000-000000000001',
       t.id, t.version, t.body, 'instagram'
from public.consent_terms t where t.slug = 'evento-contato' order by t.version desc limit 1;
insert into public.live_event_registrations (id, event_id, lead_id, contact_term_id, contact_term_version, contact_term_text)
select 'c1000000-0000-4000-8000-000000000002', 'e1000000-0000-4000-8000-000000000001', 'd1000000-0000-4000-8000-000000000001',
       t.id, t.version, t.body
from public.consent_terms t where t.slug = 'evento-contato' order by t.version desc limit 1;
insert into public.live_event_tokens (token_hash, registration_id, expires_at)
values (repeat('7', 64), 'c1000000-0000-4000-8000-000000000001', now() + interval '30 days');

select ok(
  (select count(*) = 2 from public.live_event_registrations where lead_id = 'd1000000-0000-4000-8000-000000000001'),
  'one person, two events: each registration stays with its own event'
);

-- ---------- Content shape ----------

select throws_ok(
  $$update public.live_events set topics = '[{"icon":"lei","text":"a"},{"icon":"lei","text":"b"},{"icon":"lei","text":"c"},{"icon":"lei","text":"d"}]'::jsonb
    where slug = 'teste-vazio'$$,
  '23514', null, 'at most three topics');
select throws_ok(
  $$update public.live_events set topics = '[{"icon":"nope","text":"a"}]'::jsonb where slug = 'teste-vazio'$$,
  '23514', null, 'a topic icon comes from the fixed set');
select throws_ok(
  $$update public.live_events set topics = '{"icon":"lei"}'::jsonb where slug = 'teste-vazio'$$,
  '23514', null, 'topics must be an array — refused, not an internal error');
select throws_ok(
  $$update public.live_events set ended_behavior = 'redirect' where slug = 'teste-vazio'$$,
  '23514', null, 'a redirect needs a destination');
select throws_ok(
  $$update public.live_events set ended_behavior = 'redirect', ended_redirect_path = '//evil.example' where slug = 'teste-vazio'$$,
  '23514', null, 'a protocol-relative destination is refused (no open redirect)');
select throws_ok(
  $$update public.live_events set ended_behavior = 'redirect', ended_redirect_path = 'https://evil.example' where slug = 'teste-vazio'$$,
  '23514', null, 'an absolute URL is refused');
select lives_ok(
  $$update public.live_events set ended_behavior = 'redirect', ended_redirect_path = '/china' where slug = 'teste-vazio'$$,
  'an address of this site is accepted');
select throws_ok(
  $$update public.live_events set archived_at = now() where slug = 'teste-publicado'$$,
  '23514', null, 'an event with open registrations cannot be archived');

-- ---------- The address ----------

select lives_ok(
  $$update public.live_events set slug = 'teste-vazio-2' where slug = 'teste-vazio'$$,
  'a draft nobody registered for can still change its address');
select throws_ok(
  $$update public.live_events set slug = 'teste-publicado-2' where slug = 'teste-publicado'$$,
  '23514', 'live_event_slug_locked', 'a published event keeps its address');
select throws_ok(
  $$update public.live_events set slug = 'teste-rascunho-2' where slug = 'teste-rascunho'$$,
  '23514', 'live_event_slug_locked', 'so does a draft someone already registered for');

-- ---------- Duplicate and delete ----------

create temporary table crud_results (name text primary key, payload jsonb);
grant select, insert on table crud_results to authenticated, service_role;

select set_config('request.jwt.claims', '{"sub":"f2000000-0000-4000-8000-000000000002","role":"authenticated"}', true);
set local role authenticated;
insert into crud_results values ('dup-stranger', public.duplicate_live_event('e1000000-0000-4000-8000-000000000001', 'copia-estranha', 'Cópia'));
insert into crud_results values ('del-stranger', public.delete_live_event('e1000000-0000-4000-8000-000000000003', 'teste'));
insert into crud_results values ('results-stranger', public.live_event_results('e1000000-0000-4000-8000-000000000002'));
insert into crud_results values ('overview-stranger', jsonb_build_object('rows', (select count(*) from public.live_events_overview())));
reset role;

select set_config('request.jwt.claims', '{"sub":"f2000000-0000-4000-8000-000000000001","role":"authenticated"}', true);
set local role authenticated;
insert into crud_results values ('dup', public.duplicate_live_event('e1000000-0000-4000-8000-000000000001', 'teste-copia', 'Cópia do rascunho'));
insert into crud_results values ('dup-taken', public.duplicate_live_event('e1000000-0000-4000-8000-000000000001', 'teste-publicado', 'Outra'));
insert into crud_results values ('del-published', public.delete_live_event('e1000000-0000-4000-8000-000000000002', 'teste'));
insert into crud_results values ('del-registered', public.delete_live_event('e1000000-0000-4000-8000-000000000001', 'teste'));
insert into crud_results values ('del-empty', public.delete_live_event('e1000000-0000-4000-8000-000000000003', 'criado por engano'));
reset role;

select is((select payload ->> 'code' from crud_results where name = 'dup-stranger'), 'not_authorized',
  'only the operator duplicates');
select is((select payload ->> 'code' from crud_results where name = 'del-stranger'), 'not_authorized',
  'only the operator deletes');
select ok(
  (select e.state = 'rascunho' and e.topic = 'um teste' and e.headline = 'Manchete **teste.**'
     and not exists (select 1 from public.live_event_registrations r where r.event_id = e.id)
   from public.live_events e where e.slug = 'teste-copia'),
  'a duplicate copies the content, starts as a draft and has no registrations');
select is((select payload ->> 'code' from crud_results where name = 'dup-taken'), 'slug_taken',
  'a duplicate cannot take an address in use');
select is((select payload ->> 'code' from crud_results where name = 'del-published'), 'not_draft',
  'a published event is archived, never deleted');
select is((select payload ->> 'code' from crud_results where name = 'del-registered'), 'has_registrations',
  'a draft with a registration is not deleted either');
select ok(
  (select payload ->> 'ok' = 'true' from crud_results where name = 'del-empty')
  and not exists (select 1 from public.live_events where id = 'e1000000-0000-4000-8000-000000000003')
  and exists (select 1 from public.audit_events where action = 'admin.events.deleted'
              and entity_id = 'e1000000-0000-4000-8000-000000000003' and metadata ->> 'reason' = 'criado por engano'),
  'an empty draft is deleted, with the reason in the audit trail');

-- ---------- Visits, device, purchases ----------

select set_config('request.jwt.claims', '{"role":"service_role"}', true);
set local role service_role;
select public.count_live_event_view('teste-publicado', 'instagram');
select public.count_live_event_view('teste-publicado', 'instagram');
select public.count_live_event_view('teste-rascunho', 'instagram');
insert into crud_results values ('touch-device', public.touch_live_event_registration(repeat('7', 64), 'group', 0, 'phone'));
insert into crud_results values ('touch-bad-device', public.touch_live_event_registration(repeat('7', 64), 'group', 0, 'tablet'));
reset role;

select is(
  (select views from public.live_event_page_views
   where event_id = 'e1000000-0000-4000-8000-000000000002' and origem = 'instagram'),
  2, 'visits are counted per event, per day, per channel');
select ok(
  not exists (select 1 from public.live_event_page_views where event_id = 'e1000000-0000-4000-8000-000000000001'),
  'a draft counts no visits');
select is(
  (select group_clicked_device from public.live_event_registrations where id = 'c1000000-0000-4000-8000-000000000001'),
  'phone', 'the group click keeps the class of device, nothing more');
select is((select payload ->> 'code' from crud_results where name = 'touch-bad-device'), 'invalid_request',
  'an unknown device class is refused');

insert into public.organizations (id, name, slug) values ('b1000000-0000-4000-8000-000000000001', 'Consultório', 'crud-teste-org');
insert into public.purchase_attributions (org_id, invoice_key, amount_cents, currency, paid_at, utm_campaign)
values ('b1000000-0000-4000-8000-000000000001', 'asaas:inv_1', 199000, 'BRL', now(), 'teste-publicado');

select set_config('request.jwt.claims', '{"sub":"f2000000-0000-4000-8000-000000000001","role":"authenticated"}', true);
set local role authenticated;
insert into crud_results values ('results', public.live_event_results('e1000000-0000-4000-8000-000000000002'));
insert into crud_results values ('overview', jsonb_build_object('rows', (select count(*) from public.live_events_overview())));
reset role;

select ok(
  (select (payload ->> 'registrations')::int = 1 and (payload ->> 'visits')::int = 2
     and (payload ->> 'group_phone')::int = 1
     and payload -> 'channels' @> '[{"channel":"instagram","visits":2,"registrations":1}]'::jsonb
   from crud_results where name = 'results'),
  'the results join visits and registrations by channel');
select ok(
  (select (payload ->> 'purchases')::int = 1 and (payload ->> 'revenue_cents')::int = 199000
   from crud_results where name = 'results'),
  'the purchases of a campaign are the event''s purchases');
select is((select payload ->> 'code' from crud_results where name = 'results-stranger'), 'not_authorized',
  'results are the operator''s only');
select ok(
  (select (payload ->> 'rows')::int = 0 from crud_results where name = 'overview-stranger')
  and (select (payload ->> 'rows')::int >= 3 from crud_results where name = 'overview'),
  'the overview lists events for the operator and nothing for anyone else');

select * from finish();
rollback;
