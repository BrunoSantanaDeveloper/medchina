import { Box, Button, Card, CardContent, Typography } from "@mui/material";

import NiEllipsisHorizontal from "@/icons/nexture/ni-ellipsis-horizontal";
import NiLike from "@/icons/nexture/ni-like";
import NiUnlike from "@/icons/nexture/ni-unlike";
import NextureIcons from "@/icons/nexture-icons";
import { cn } from "@/lib/utils";

export default function ExtensionInfo() {
  return (
    <Card className="mb-5">
      <CardContent className="flex flex-col items-center gap-5">
        <Box className="flex flex-col items-center">
          <Box className="bg-secondary/10 mb-2 flex h-20 w-20 flex-none items-center justify-center rounded-4xl">
            <NextureIcons icon="NiFlask" size="large" className="text-secondary" />
          </Box>

          <Typography variant="subtitle1" component="p">
            Color Analysis
          </Typography>
          <Typography variant="body2" component="p" className="text-text-secondary -mt-0.5">
            Research
          </Typography>
        </Box>

        <Box className="flex w-full max-w-sm flex-row gap-1">
          <Button
            size="medium"
            color="grey"
            variant="pastel"
            startIcon={<NiLike size={"medium"} />}
            className={cn(
              "[.active]:text-primary [.active]:bg-grey-25 hover:text-primary [.active:hover]:text-text-primary min-w-0 flex-1 md:min-w-16",
              "active",
            )}
          >
            2,781
          </Button>
          <Button
            size="medium"
            color="grey"
            variant="pastel"
            startIcon={<NiUnlike size={"medium"} />}
            className={cn(
              "[.active]:text-secondary [.active]:bg-grey-25 hover:text-secondary [.active:hover]:text-text-primary min-w-0 flex-1 md:min-w-16",
            )}
          >
            48
          </Button>
          <Button
            className="icon-only flex-none"
            size="medium"
            color="grey"
            variant="pastel"
            startIcon={<NiEllipsisHorizontal size={"medium"} />}
          />
        </Box>

        <Box className="w-full">
          <Typography variant="body1" className="text-text-primary text-center">
            Decode color instantly. From branding to design, it reveals palette harmony, emotional impact, and style
            fit.
          </Typography>
        </Box>
      </CardContent>
    </Card>
  );
}
