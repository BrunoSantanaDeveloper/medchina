"use client";

import AccessEventsAdmin from "./components/access-events-admin";
import AuditEventsAdmin from "./components/audit-events-admin";
import ProcessingFailuresAdmin from "./components/processing-failures-admin";
import WaLogAdmin from "./components/wa-log-admin";
import Link from "next/link";
import { useEffect, useState } from "react";

import { Alert, Box, Breadcrumbs, Card, CardContent, Grid, Tab, Tabs, Typography } from "@mui/material";

import { isSupabaseConfigured } from "@flyee/auth";
import { createClient } from "@flyee/auth/client";

/**
 * Superadmin audit console. RLS is the real gate (non-superadmins get
 * empty reads); the client-side check only improves UX.
 */
export default function AdminAudit() {
  const [tab, setTab] = useState(0);
  const [allowed, setAllowed] = useState<boolean | null>(null);

  useEffect(() => {
    const check = async () => {
      if (!isSupabaseConfigured) {
        setAllowed(false);
        return;
      }
      const supabase = createClient();
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) {
        setAllowed(false);
        return;
      }
      const { data } = await supabase.from("profiles").select("is_superadmin").eq("id", user.id).maybeSingle();
      setAllowed(Boolean(data?.is_superadmin));
    };
    check();
  }, []);

  return (
    <Grid container spacing={5}>
      <Grid size={12}>
        <Typography variant="h1" component="h1" className="mb-0">
          Auditoria e logs
        </Typography>
        <Breadcrumbs>
          <Link color="inherit" href="/inicio">
            Início
          </Link>
          <Typography variant="body2">Admin</Typography>
          <Typography variant="body2">Auditoria</Typography>
        </Breadcrumbs>
      </Grid>

      {allowed === false && (
        <Grid size={12}>
          <Alert severity="error" className="neutral bg-background-paper/60!">
            Esta área é restrita aos superadmins da plataforma.
          </Alert>
        </Grid>
      )}

      {allowed && (
        <Grid size={12}>
          <Card component="section">
            <CardContent>
              <Tabs value={tab} onChange={(_, value) => setTab(value)} className="mb-6">
                <Tab label="Trilha de auditoria" />
                <Tab label="Acesso" />
                <Tab label="Falhas de processamento" />
                <Tab label="Log do WhatsApp" />
              </Tabs>
              <Box hidden={tab !== 0}>{tab === 0 && <AuditEventsAdmin />}</Box>
              <Box hidden={tab !== 1}>{tab === 1 && <AccessEventsAdmin />}</Box>
              <Box hidden={tab !== 2}>{tab === 2 && <ProcessingFailuresAdmin />}</Box>
              <Box hidden={tab !== 3}>{tab === 3 && <WaLogAdmin />}</Box>
            </CardContent>
          </Card>
        </Grid>
      )}
    </Grid>
  );
}
