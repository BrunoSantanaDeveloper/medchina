"use client";
import ClipboardPasteBasic from "./examples/clipboard-paste-basic";
import Link from "next/link";

import { Breadcrumbs, Card, CardContent, Typography } from "@mui/material";
import { Grid } from "@mui/material";

export default function ClipboardPastePage() {
  return (
    <Grid container spacing={5}>
      <Grid size={12} className="mb-2">
        <Typography variant="h1" component="h1" className="mb-0">
          Clipboard Paste
        </Typography>
        <Breadcrumbs>
          <Link color="inherit" href="/inicio">
            Home
          </Link>
          <Link color="inherit" href="/ui">
            UI Elements
          </Link>
          <Link color="inherit" href="/ui/mui-x">
            MUI X
          </Link>
          <Link color="inherit" href="/ui/mui-x/data-grid">
            Data Grid
          </Link>
          <Typography variant="body2">Clipboard Paste</Typography>
        </Breadcrumbs>
      </Grid>

      <Grid size={12}>
        <Card>
          <CardContent>
            <Typography variant="h5" component="h5" className="card-title">
              Pro Version
            </Typography>
            <ClipboardPasteBasic />
          </CardContent>
        </Card>
      </Grid>
    </Grid>
  );
}
