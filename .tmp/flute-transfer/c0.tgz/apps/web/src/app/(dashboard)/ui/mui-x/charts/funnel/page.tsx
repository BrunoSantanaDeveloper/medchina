"use client";
import Link from "next/link";

import { Breadcrumbs, Card, CardContent, Grid, Typography } from "@mui/material";

import BasicFunnel from "@/app/(dashboard)/ui/mui-x/charts/funnel/examples/basic-funnel";
import Curve from "@/app/(dashboard)/ui/mui-x/charts/funnel/examples/Curve";

export default function FunnelCharts() {
  return (
    <Grid container spacing={5}>
      <Grid size={12} className="mb-2">
        <Typography variant="h1" component="h1" className="mb-0">
          Funnel Charts
        </Typography>
        <Breadcrumbs>
          <Link color="inherit" href="/inicio">
            Home
          </Link>
          <Link color="inherit" href="/ui/mui-x">
            MUI X
          </Link>
          <Link color="inherit" href="/ui/mui-x/charts">
            Charts
          </Link>
          <Typography variant="body2">Funnel</Typography>
        </Breadcrumbs>
      </Grid>

      <Grid size={12}>
        <Card>
          <CardContent>
            <Typography variant="h5" component="h5" className="card-title">
              Basic Funnel Chart
            </Typography>
            <BasicFunnel />
          </CardContent>
        </Card>
      </Grid>

      <Grid size={12}>
        <Card>
          <CardContent>
            <Typography variant="h5" component="h5" className="card-title">
              Curve Types
            </Typography>
            <Curve />
          </CardContent>
        </Card>
      </Grid>
    </Grid>
  );
}
